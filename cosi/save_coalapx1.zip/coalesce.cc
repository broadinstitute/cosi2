/* $Id: coalesce.c,v 1.3 2011/05/04 15:46:19 sfs Exp $ */

#include <algorithm>
#include <map>
#include <stdexcept>
#include <boost/foreach.hpp>
#include <cosi/coalesce.h>
#include <cosi/demography.h>
#include <cosi/node.h>
#include <cosi/seglist.h>

#ifdef COSI_DEV_COALAPX
#include <cosi/order_statistics.hpp>
#endif

namespace cosi {

void chkMap( const std::map< loc_t, int >& m );

namespace coal {

extern size_t lastIntersCount;

Coalesce::Coalesce( DemographyP demography_ ):
	demography( demography_ ), lastrate(0.0), maxCoalDist( plen_t( 1.0 ) ), maxCoalDistCvxHull( False ) { }


	
/* 
 * Calculates the coalesce rate according to the number of
 * nodes in each population. 
 */
double 
Coalesce::coalesce_get_rate (void) const
{
	int numpops = demography->dg_get_num_pops();
	int i;
	double rate = 0;
	nchroms_t numnodes;
	nchroms_t popsize;

	
	for (i = 0; i < numpops; i++) {
		numnodes = demography->dg_get_num_nodes_in_pop_by_index (i);
		popsize = demography->dg_get_pop_size_by_index (i);
		if (numnodes > 1  /*&& popsize > 0*/ ) {
			prob_t coalRate = (double) (numnodes * (numnodes - 1)) 
				/ (4 * std::max( popsize, 1 ) );
#ifdef COSI_DEV_COALAPX
			Pop *popptr = demography->dg_get_pop_by_index (i);

			typedef int ninters_t;
			map< loc_t, ninters_t > loc2count;
#if 1
			int npairs = 0;
			int npairs_tot = 0;
			int n_contain = 0;
			for ( int ii = 0; ii < popptr->pop_get_num_nodes(); ii++ ) {
				const Node *node1 = popptr->pop_get_node(ii);
				 for ( int jj = ii+1; jj < popptr->pop_get_num_nodes(); jj++ ) {
					 const Node *node2 = popptr->pop_get_node(jj);
					 npairs_tot++;
					 if (	!( seglist_beg( node1->getSegs() ) - seglist_end( node2->getSegs() ) > maxCoalDist ||
									 seglist_beg( node2->getSegs() ) - seglist_end( node1->getSegs() ) > maxCoalDist ) ) {
							npairs++;
							loc_t inters_beg = std::max( seglist_beg( node1->getSegs() ), seglist_beg( node2->getSegs() ) );
							// if ( equal_eps( inters_beg, loc_t( 0.63281095310391 ) ) )
							// 	 PRINT5( "aha", node1->getSegs(), node2->getSegs(), inters_beg, loc2count[ inters_beg ] );
							loc2count[ inters_beg ]++;
					 }
				 }
				 if ( seglist_beg( node1->getSegs() ) <= loc_t( 0.63281095310391 ) && loc_t( 0.63281095310391 ) <= loc_t( seglist_end( node1->getSegs() ) + len_t( maxCoalDist ) ) ) {
					 //	 PRINT2( n_contain, node1->getSegs() );
					 n_contain++;
				 }
			}
// 			map< loc_t, ninters_t >::const_iterator lb_it = loc2count.lower_bound( loc_t( 0.63281095310391 ) );
// //			PRINT2( n_contain, lb_it == loc2count.end() );
// 			if ( lb_it != loc2count.end() ) {
// 				 // PRINT2( lb_it->first, lb_it->second );
// 				 // PRINT2( boost::prior( lb_it )->first, boost::prior( lb_it )->second );
// 			}
			

			ninters_t totCmp = 0;
			ForMap( loc_t, ninters_t, m, loc2count )
				 totCmp += m->second;

			assert( totCmp == npairs );

#ifndef NDEBUG			
			chkMap( loc2count );
#endif
			
#endif  // #ifdef COSI_DEV_COALAPX

			typedef util::order_statistics_tree<ploc_t> ost_t;
			typedef ost_t::iterator ost_iter_t;
			ost_t begs, ends;
			
			nchroms_t n_beg0 = 0;
			for ( int ii = 0; ii < popptr->pop_get_num_nodes(); ii++ ) {
				const Node *n = popptr->pop_get_node( ii );
				ploc_t beg( get_ploc( seglist_beg( n->getSegs() ) ) );
				if ( beg == ploc_t(0.0) )
					 n_beg0++;
				else
					 begs.insert( beg );

				ploc_t end_ext = get_ploc( seglist_end( n->getSegs() ) ) + maxCoalDist;
				if (  end_ext < ploc_t(1.0) )
					 ends.insert( end_ext );
			}
			size_t n_pairs2 = n_beg0 * (n_beg0-1) / 2;
			for ( ost_iter_t bi = begs.begin(); bi != begs.end(); bi++ ) {
				ost_iter_t closestEnd = ends.lower_bound( *bi );
				size_t n_end_before = closestEnd == ends.end() ? ends.size() : closestEnd.position();
				size_t n_beg_after = begs.size() - bi.position();

				n_pairs2 += ( popptr->pop_get_num_nodes() - n_end_before - n_beg_after );
			}

			//PRINT4( npairs_tot, npairs, n_pairs2, lastIntersCount );			
			if (  n_pairs2 != npairs  ||  lastIntersCount != n_pairs2 ) {
//				PRINT3( npairs, n_pairs2, lastIntersCount ); throw std::runtime_error( "inters count mismatch" );
				PRINT3( npairs, n_pairs2, lastIntersCount ); throw std::runtime_error( "inters count mismatch" );
			}
			
			
			coalRate = ((double)n_pairs2) / ( 2 * std::max(popsize,1) );
			//PRINT3( npairs, npairs_tot, coalRate );

			
#endif  // #ifdef COSI_DEV_COALAPX			
			
#ifdef COSI_DEV			
			demography->dg_get_pop_by_index( i )->setCoalRate( coalRate );
#endif			
			rate += coalRate;
		}
	}
	
	lastrate = rate;
	return rate;
}

int
Coalesce::coalesce_pick_popindex () const
{
	double  rate = 0,
		 randcounter = random_double() * lastrate;
	int     popindex = 0,
		 numpops = demography->dg_get_num_pops(),
		 numnodes,
		 popsize,
		 i;

	if (numpops > 1) {
		for (i = 0; i < numpops && randcounter > rate; i++) {
			numnodes = demography->dg_get_num_nodes_in_pop_by_index (i);
			popsize = demography->dg_get_pop_size_by_index (i);
			if (numnodes > 1 /*&& popsize > 0*/ )
				 rate += (double) (numnodes * (numnodes - 1)) 
					 / (4 * std::max( popsize, 1 ) );
		}		
		popindex = i - 1;
	}

	return popindex;
}  // Coalesce::coalesce_pick_popindex()

#ifdef COSI_DEV_APX
#endif  // #ifdef COSI_DEV_APX

}  // namespace coal

}  // namespace cosi
