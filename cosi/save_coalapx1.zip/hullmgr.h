#ifndef __COSI_INCLUDE_HULLMGR_H
#define __COSI_INCLUDE_HULLMGR_H

#include <cstdlib>
#include <utility>
#include <cosi/defs.h>
#include <cosi/order_statistics.hpp>
#include <cosi/utils.h>

namespace cosi {
namespace coal {

#ifdef COSI_DEV_COALAPX

//
// Class: HullMgr
//
// Keeps track of the convex hulls of the seglists of all <Nodes>, and of the pairs of intersecting hulls.
// Supports choosing a pair of intersecting hulls uniformly at random from all such intersecting pairs, and
// updating the hull information through all standard operations (recombinations, coalescences,
// gene conversions, migrations).
//
// Complexity:
//
//    space complexity - for n hulls, O(n) storage.
//    time complexity - O(lg n) for update operations.
//
// Implementation notes:
//
// Because recombination points are chosen randomly on a uniform line, we assume that no two such points
// fall into exactly the same place.  So, at each loc except <MIN_LOC>, nbegs+nends <= 2 where nbegs is
// the number of hulls starting at that loc and nends is the number of hulls ending at that loc.
//
// Design rationale:
//
//    - why a simple weighted interval map is not enough?  we need to keep partial sums.  but, presumably
//      a map does that?   
//
// Implementation todo:
//
//   - handle additional cases
//
//       - when something fully coalesces
//       - migration in and out
//       - gene conversion (can/should we re-implement it as a pair of recombs?)
//
//   - keep track of node ids
//
//   - consider using knowledge of the genetic map to optimize access times to elements in hotspots.
//     note though, that for coalescence operations we might need different access probabilities.
//     but, we have some info on them if we keep the intersection counts.
//
//   - zero things out instead of deleting?
//
//   - remove seglist_summaries if no longer helpful
//
//   - avoid multiple tree traversals
//     - support finding several cose-by things at once
//
class HullMgr {
public:

	 // Logical type: ninters_t
	 // A count of hull intersections; has units of nchroms * nchroms.
	 typedef int ninters_t;  // signed, for now, to allow negative deltas.

	 // Constructor: HullMgr
	 // Construct a HullMgr.  It is not yet initialized (see <addLeaves()> for that).
	 // Params:
	 //    margin_ - specifies what near-intersections are considered to be intersections;
	 //      specifically, for a seglist [beg,end] the corresponding hull is [beg, end+margin].
	 HullMgr( len_t margin_ );
	 virtual ~HullMgr();

	 void setMargin( len_t margin_ ) { this->margin = margin_; }
	 void setMargin( plen_t margin_ ) { this->setMargin( len_t( margin_ ) ); }

	 // Method: addLeaves
	 // Initialize the HullMgr with the specified number of leaf segments, each of which has the hull [0,1].
	 // Params:
	 //    leafCount - initial number of leaves
//	 void addLeaves( nchroms_t leafCount );


	 // Method group: ARG operations

	 struct Hull;

	 
	 Hull addHull( loc_t beg, loc_t end ); 
	 void removeHull( Hull ); 

	 // Method: recomb
	 //
	 // Called after each recombination to update the hull information.
	 //
	 // Params:
	 //
	 //    beg1,end1 and beg2,end2 - the two hulls resulting from the recombination.
	 //      The original hull was [beg1,end2].  If the recomb point fell in the middle of a seg,
	 //      then end1 == beg2.  If the recomb point fell in a gap, then end1 < beg2.
	 //
	 //    loc - the location of recombination
	 //
	 // Complexity: lg n, where n is the current number of hulls.
	 //
	 void recomb( Hull h, loc_t loc, loc_t beg1, loc_t end1, loc_t beg2, loc_t end2,
								Hull *h_left, Hull *h_right );
	 
	 void coalesce( Hull h1, Hull h2 );
	 Hull coalesce( Hull h1, Hull h2, loc_t newbeg, loc_t newend );

	 // End method group: ARG operations


	 // Method group: Debugging / testing
	 
	 // Method: chkMap
	 // Check that the inters counts represented by this HullMgr match the counts in the passed map.
	 void chkMap( const map< loc_t, ninters_t >& ) const;

private:
	 // Field: margin
	 //
	 // Specifies what near-intersections are considered to be intersections;
	 // specifically, for a seglist [beg,end] the corresponding hull is [beg, end+margin].
	 // So, two seglists [beg1,end1] and [beg2,end2] where end1 < beg2 have intersecting hulls
	 // if end1 is within 'margin' of beg2.
	 len_t margin;

	 typedef std::pair<loc_t, ninters_t> pair_t;

	 // Type: ost_t
	 // An Order Statistics Tree which lets us efficiently query, for each element, the number
	 // of elements less than it.
	 typedef util::order_statistics_tree< /* ValueType= */ pair<loc_t, ninters_t>,
																				/* Comparator= */ std::less<loc_t>,
																												 /* KeyExtractor= */ util::FieldRef< pair_t, loc_t, &pair_t::first > ,
																												 /* WeightExtractor= */ util::FieldRef< pair_t, ninters_t, &pair_t::second > > ost_begs_t;
	 
	 typedef ost_begs_t::iterator ost_begs_iter_t;

	 // Field: begs
	 // For each beg, the number of intersections starting there; except if there are several begs
	 // at the same loc, then the first loc stores the number of intersections there, and the
	 // others store zero.
	 ost_begs_t begs;

	 typedef util::order_statistics_tree< /* ValueType= */ loc_t > ost_ends_t;
	 typedef ost_ends_t::iterator ost_ends_iter_t;

	 // Field: ends
	 // The locations of hull ends.
	 ost_ends_t ends;

public:	 
	 struct Hull {
			ost_begs_t::iterator beg_it;
			ost_ends_t::iterator end_it;

			Hull() { }
			Hull( ost_begs_t::iterator beg_it_,
						ost_ends_t::iterator end_it_ ):
				beg_it ( beg_it_ ), end_it ( end_it_ ) { }
	 };

	 friend std::ostream& operator<< ( std::ostream& s, HullMgr::Hull h ) {
		 s << "(" << h.beg_it->first << " - " << *h.end_it << "; " << h.beg_it->second << ")";
		 return s;
	 }

	 
private:	 

	 loc_t getLoc( ost_begs_t::const_iterator i ) const { assert( i != begs.end() ); return i->first; }
	 ninters_t getIntersCount( ost_begs_t::const_iterator i ) const {
		 assert( i != begs.end() ); return i->second;
	 }
	 ninters_t& getIntersCount( ost_begs_t::iterator i ) {
		 assert( i != begs.end() ); return i->second;
	 }

public:

	 // Method: getNumIntersections
	 // Returns the current number of intersecting hull pairs.
	 ninters_t getNumIntersections() const { return begs.totalWeight(); }
	 

};  // class HullMgr

#endif  // #ifdef COSI_DEV_COALAPX

}  // namespace coal
}  // namespace cosi

#endif  // #ifndef __COSI_INCLUDE_HULLMGR_H
