//
// Header: ehh.h
//
// Code to compute EHH and EHH-based statistics (iHS, deltaIHH, XP-EHH).
// See http://www.sciencemag.org/content/327/5967/883.abstract
//

#ifndef __INCLUDE_COSI_EHH_H
#define __INCLUDE_COSI_EHH_H

#include <cstdlib>
#include <vector>
#include <cosi/defs.h>
#include <cosi/leafset.h>
#include <cosi/mutlist.h>

namespace cosi {

using namespace std;

namespace ehh {
// Type: ehh_t
// Represents an EHH value.
typedef double ehh_t;
  
typedef double ihh_t;

struct iHSTestConfig {
	 ehh_t cutoffEHH;
	 ehh_t startAllEHH;
	 freq_t minDerivedFreq;

	 iHSTestConfig():
		 cutoffEHH( 0.05 ), startAllEHH( 1.00 ), minDerivedFreq( 0.0 ) { }
};

// FuncP: computeEHH
// Compute EHH for the given set of leaves, starting from the given core and going
// in a given direction.
vector<ehh_t> computeEHH( const vector<Mut>& mutlist,
													leafset_p coreLeafset,
													ehh_t ehhCutoff = 0.05 );

ihh_t computeIHH( MutlistP mutlist,
									loc_t coreSNP, dir_t dir,
									leafset_p coreLeafset,
									leafset_p popLeafset,
									ehh_t ehhCutoff = 0.05 );
  
}  // namespace ehh

}  // namespace cosi

#endif
// #ifndef __INCLUDE_EHH_H
