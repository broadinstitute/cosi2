/* $Id: simulator.c,v 1.3 2011/05/04 15:46:19 sfs Exp $ */

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <cosi/historical.h>
#include <cosi/migrate.h>
#include <cosi/recomb.h>
#include <cosi/geneconversion.h>
#include <cosi/demography.h>
#include <cosi/coalesce.h>
#include <cosi/simulator.h>
#include <cosi/leafset.h>
#include <cosi/genmap.h>
#include <cosi/mutlist.h>
#include <cosi/mutate.h>

namespace cosi {

Simulator::Simulator( DemographyP demography_, GenMapP genMap_ ):
	demography( demography_ ), genMap( genMap_ ),
	coalesce_rate(0.0),
	migrate_rate(0.0),
	recombination_rate(0.0),
	geneconv_rate(0.0),
	poisson_rate(0.0)
{
}

/* To execute the coalescent simulator:
 * 1. Calculate the times to the next historical and poisson events.
 * 2. Choose the closest event, and execute it.
 * 3. Repeat until sim_complete().
 * 
 * Important assumption:
 * Historical events are appropriately spaced such that
 * historical_event_time will never be negative unless
 * there are no historical events left.
 *
 */
genid
Simulator::sim_execute (void) 
{
	genid gen = ZERO_GEN;
	gens_t historical_event_time;
	gens_t poisson_event_time;	
	int coal = 0;
	bool_t complete_flag = False;	

	while (complete_flag == 0) {

	  coal = 0;
	  historical_event_time = sim_get_time_till_next_hist_event (gen);
	  poisson_event_time = sim_get_time_till_next_pois_event ();
	  
	  if (DEBUG) { PRINT6( recombination_rate, coalesce_rate, migrate_rate, geneconv_rate, poisson_event_time, historical_event_time ); }

	  if ( is_null( historical_event_time )
				 || poisson_event_time < historical_event_time) {
	    gen += poisson_event_time;
	    coal = sim_do_poisson (gen);
	    if (coal) {complete_flag = demography->dg_done_coalescent();}
	  }
	  else {
	    gen += historical_event_time;
	    gen = histEvents->historical_event_execute(gen);
	    complete_flag = demography->dg_done_coalescent(); 
	  }

	}
	return gen;
}

void Simulator::sim_setCoalesce( CoalesceP coalesce_ ) {
	coalesce = coalesce_;
}


/*****************************************************************/
/* INTERNAL FUNCTIONS */

gens_t
Simulator::sim_get_time_till_next_hist_event (genid gen) 
{
	return histEvents->historical_get_time_till_next_event (gen);
}

gens_t
Simulator::sim_get_time_till_next_pois_event (void) 
{
	return gens_t( poisson_get_next (sim_get_poisson_rate()) );
}

prob_t
Simulator::sim_get_poisson_rate(void)
{
	coalesce_rate = coalesce->coalesce_get_rate();
	migrate_rate = ToDouble( migrate->migrate_get_all_nodes_rate() );
	recombination_rate = ToDouble( recomb->getAllNodesRecombRate() * genMap->getRegionRecombRateAbs() );
	geneconv_rate = ToDouble( geneConversion->getAllNodesGeneConvRate() * genMap->getRegionRecombRateAbs() );

	poisson_rate = (double) (coalesce_rate + migrate_rate + recombination_rate + geneconv_rate);
	return poisson_rate;
}

int 
Simulator::sim_do_poisson (genid gen) 
{
  int did_coal = 0;
  prob_t randdouble = random_double();
  int popindex;

  if (randdouble < recombination_rate / poisson_rate) {
    recomb->recomb_execute( gen, randdouble / ( recombination_rate / poisson_rate ) );
  }
  else if (randdouble < (recombination_rate + migrate_rate) / poisson_rate) {
    migrate->migrate_execute(gen);
  }
  else if (randdouble < (recombination_rate + migrate_rate + coalesce_rate) / poisson_rate) {
    popindex = coalesce->coalesce_pick_popindex();
		//if ( gen > genid(400) ) PRINT3( gen, coalesce_rate, popindex );
    demography->dg_coalesce_by_index (popindex, gen);
    did_coal = 1;
  }
  else {
		geneConversion->gc_execute(gen,
															 ( randdouble - (recombination_rate + migrate_rate + coalesce_rate) / poisson_rate ) /
															 ( 1.0 - (recombination_rate + migrate_rate + coalesce_rate) / poisson_rate ) );
  }
  return did_coal;
}

bool_t
Simulator::sim_complete (void) const {
	return demography->dg_done_coalescent();

}
 
}  // namespace cosi
