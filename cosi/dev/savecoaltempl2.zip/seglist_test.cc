#include <cosi/seglist.h>

int main(int /*argc*/, char ** /*argv[]*/ ) {
	return cosi::seglist::seglist_run_tests();
}
