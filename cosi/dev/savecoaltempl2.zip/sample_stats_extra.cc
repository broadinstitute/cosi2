/*
 * Program: sample_stats_extra
 *
 * Compute various summary statistics for a set of simulations in ms output format.
 * Some extensions of ms format are accepted.  Which statistics are gathered, can be configured
 * on the command line.
 *
 * For each simulation, one line of statistics is output.
 *
 * Adapted from the ms package by Richard Hudson.
 * See http://home.uchicago.edu/rhudson1/source/mksamples.html 
 *
 * Usage:
 *
 * sample_stats_extra MARGIN afsMax (dmin dmax)*
 *
 * Args:
 *
 *    MARGIN - margin of simulated region to ignore; this fraction from the start and from the end
 *       of the region will be ignored, stats will be gathered only from the middle portion of the region.
 *    afsMax - when gathering the allele frequency spectrum, gather the fraction of SNPs having 1, 2, ..., afsMax
 *       chroms with derived allele
 *    dmin dmax - gather parameters of the distribution of LD for pairs of SNPs at physical separation of between dmin and dmax
 *       (specified as fraction of total region length)
 */


#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <stdint.h>
#include <limits>
#include <stdexcept>
#include <sstream>
#include <ios>
#include <iostream>
#include <algorithm>
#include <vector>
#include <utility>
#include <iterator>
#include <set>
#include <locale>
#include <boost/assign.hpp>
#include <boost/math/special_functions/fpclassify.hpp>
#include <boost/foreach.hpp>
#include <boost/swap.hpp>
#include <boost/range/concepts.hpp>
#include <boost/range/numeric.hpp>
#include <boost/iterator/iterator_traits.hpp>
#include <boost/cstdint.hpp>
#include <boost/next_prior.hpp>
#include <boost/program_options.hpp>
#include <boost/tokenizer.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/function.hpp>
//#include <boost/lambda/lambda.hpp>
//#include <boost/lambda/bind.hpp>
#include <boost/phoenix/bind/bind_member_variable.hpp>
#include <boost/phoenix/bind/bind_member_function.hpp>
#include <boost/phoenix/core/value.hpp>
#include <boost/phoenix/core/argument.hpp>
#include <boost/phoenix/operator.hpp>
#include <boost/regex.hpp>
#include <boost/accumulators/framework/accumulator_set.hpp>
#include <boost/accumulators/statistics/stats.hpp>
#include <boost/accumulators/statistics/sum_kahan.hpp>
#include <boost/accumulators/statistics/mean.hpp>
#include <boost/accumulators/statistics/variance.hpp>
#include <boost/accumulators/statistics/skewness.hpp>
#include <boost/accumulators/statistics/kurtosis.hpp>
#include <boost/accumulators/statistics/moment.hpp>
#include <boost/accumulators/statistics/covariance.hpp>
#include <boost/accumulators/statistics/variates/covariate.hpp>
#include <boost/accumulators/statistics/extended_p_square_quantile.hpp>
#include <boost/array.hpp>
#include <Sequence/SimParams.hpp>

#ifdef __GNUC__
#if ( __GNUC__ > 4 ) || ( ( __GNUC__ == 4 ) && ( __GNUC_MINOR__ > 5 ) )
#pragma GCC diagnostic push
#endif
#pragma GCC diagnostic ignored "-Wmissing-declarations"
#endif

namespace cosi {

using std::vector;
using std::set;
using std::ostream;
using std::istream;
using std::ostream_iterator;
using std::ostringstream;
using std::istringstream;
using std::cout;
using std::cerr;
using std::endl;
using std::ios_base;
using std::pair;
using std::make_pair;
using std::locale;
using std::ctype;
using std::string;

namespace phx = boost::phoenix;
using phx::placeholders::arg1;

double tajd(int, int, double) ;

string Date( );

typedef double cosi_double;
inline cosi_double ToDouble( const cosi_double& x ) { return x; }
vector<string> Split( string s, const string& separators = " \t" );
void Split( const string& s, const string& sep, string& part1, string& part2 );
void Split( const string& s, const string& sep, string& part1, string& part2, string& part3 );
string Join( const string& sep, const vector<string>& strings );
string Join( const string& sep, const string& s1, const string& s2 );
string Join( const string& sep, const string& s1, const string& s2, const string& s3 );
string Join( const string& sep, const string& s1, const string& s2, const string& s3, const string& s4 );
string Join( const string& sep, const string& s1, const string& s2, const string& s3, const string& s4, const string& s5 );
string MakeValidIdentifier( const string& s );
double Frac( int a, int b );

class SNPCond;
ostream& operator<<( ostream& os, const SNPCond& snpCond );


#define ForEach BOOST_FOREACH

// The following PRINT macros are intended primarily for debugging.

#define PRCORE(X) #X " = " << (X)
#define PRINT(X) cerr << Date() << " at " << __FILE__ << ":" << __LINE__ << " " << PRCORE(X) << endl
#define PRINT2(X, Y) cerr << Date() << " at " << __FILE__ << ":" << __LINE__ << " " << PRCORE(X) << ", " << PRCORE(Y) << endl
#define PRINT3(X, Y, Z) cerr << Date() << " at " << __FILE__ << ":" << __LINE__ << " " << PRCORE(X) << ", " << PRCORE(Y) << ", " \
	<< PRCORE(Z) << endl
#define PRINT4(X, Y, Z, W) cerr << Date() << " at " << __FILE__ << ":" << __LINE__ << " " << PRCORE(X) << ", " << PRCORE(Y) << ", " \
	<< PRCORE(Z) << ", " << PRCORE(W) << endl
#define PRINT5(X, Y, Z, W, T) cerr << Date() << " at " << __FILE__ << ":" << __LINE__ << " " << PRCORE(X) << ", " << PRCORE(Y) << ", " \
	<< PRCORE(Z) << ", " << PRCORE(W) << ", " << PRCORE(T) << endl
#define PRINT6(X, Y, Z, W, T, U) cerr << Date() << " at " << __FILE__ << ":" << __LINE__ << " " << PRCORE(X) << ", " << PRCORE(Y) << ", " \
	<< PRCORE(Z) << ", " << PRCORE(W) << ", " << PRCORE(T) << ", "				\
	<< PRCORE(U) << endl
#define PRINT7(X, Y, Z, W, T, U, V) cerr << Date() << " at " << __FILE__ << ":" << __LINE__ << " " << PRCORE(X) << ", " << PRCORE(Y) \
  << ", " << PRCORE(Z) << ", " << PRCORE(W) << ", " << PRCORE(T) << ", " \
  << PRCORE(U) << ", " << PRCORE(V) << endl

string Date( )
{    char nowstr[80];
	time_t nowbin;
	const struct tm *nowstruct;
	static bool locale_has_been_set = false;
	if( ! locale_has_been_set ) {
		(void)setlocale(LC_ALL, "");
		locale_has_been_set = true;
	}
	if (time(&nowbin) == (time_t) - 1) return "(date unavailable - time failed)";
	nowstruct = localtime(&nowbin);
	if (strftime(nowstr, 80, "%a %b %d %H:%M:%S %Y", nowstruct) == (size_t) 0)
		 return "(date unavailable - strftime failed)";
	return string(nowstr);
}

bool compute_LD( int site_i, int site_j, int nsam, char **list,
								 double *r2, double *Dprime );

//////////////////////////////////////////////////////


double nucdiv(int, int, char **);
double hfay(int, int, char **);
double thetah(int, int, char **);
void
biggerlist(int nsam, unsigned nmax, char **list );

void chk_helper( bool cond, const char *file, int line, const char *msg );
void chk_helper( bool cond, const char *file, int line, const char *msg ) {
	if ( !cond ) {
		ostringstream s;
		s << "ERROR: file=" << file << " line=" << line << " msg=" << msg << endl;
		throw std::logic_error( s.str() );
	}
}

#define chk( cond ) chk_helper( cond, __FILE__, __LINE__, #cond )

char **
cmatrix(int nsam,int len);
void free_cmatrix(char **cm, int nsam );

int maxsites = 1000 ;

template <typename T>
inline T getVal( const char *str ) {
	istringstream s( str );
	s.exceptions( ios_base::failbit | ios_base::badbit );
	T val;
	s >> val;
	chk( s.eof() );
	return val;
}

template <typename TA, typename TB>
inline ostream& operator<<( ostream& s, const pair<TA,TB>& p ) {
	s << "(" << p.first << "," << p.second << ")";
	return s;
}

template <class T>
inline ostream& operator<<( ostream& s, const vector<T>& v) {
	s << "[";

	for(typename std::vector<T>::const_iterator it = v.begin();
			it != v.end();
			it++) {
		s<<(*it)<<", ";
	}
	s << "]";
	return s;
}

//
// Function: Split
//
// Split a string based on separators.
//
vector<string> Split( string s, const string& separators ) {
	typedef boost::tokenizer<boost::char_separator<char> > 
		 tokenizer;
  boost::char_separator<char> sep(separators.c_str());
  tokenizer tokens(s, sep);
	vector<string> result( tokens.begin(), tokens.end() );
	return result;
}

void Split( const string& s, const string& sep, string& part1, string& part2 ) {
	vector<string> parts( Split( s, sep ) );
	if ( parts.size() > 2 ) throw std::logic_error( "too many parts" );
	part1.clear();
	part2.clear();
	if ( parts.size() >= 1 ) part1 = parts[0];
	if ( parts.size() >= 2 ) part2 = parts[1];
}

void Split( const string& s, const string& sep, string& part1, string& part2, string& part3 ) {
	vector<string> parts( Split( s, sep ) );
	if ( parts.size() > 3 ) throw std::logic_error( "too many parts" );
	part1.clear();
	part2.clear();
	part3.clear();
	if ( parts.size() >= 1 ) part1 = parts[0];
	if ( parts.size() >= 2 ) part2 = parts[1];
	if ( parts.size() >= 3 ) part3 = parts[2];
}

//
// Function: Join
//
// Joint strings with a separator
//
string Join( const string& sep, const vector<string>& strings ) {
	vector<string> strings_f;
	ForEach( string s, strings ) if ( !s.empty() ) strings_f.push_back( s );
	ostringstream out;
	copy( strings_f.begin(), strings_f.end(), ostream_iterator<string>( out, sep.c_str() ) );
	return out.str();
}

template <typename T> vector<T> MakeVec() { return vector<T>(); }
template <typename T> vector<T> MakeVec( const T& v1 ) { return vector<T>( 1, v1 ); }
template <typename T> vector<T> MakeVec( const T& v1, const T& v2 ) {
	vector<T> v( MakeVec( v1 ) );
	v.push_back( v2 );
	return v;
}
template <typename T> vector<T> MakeVec( const T& v1, const T& v2, const T& v3 ) {
	vector<T> v( MakeVec( v1, v2 ) );
	v.push_back( v3 );
	return v;
}
template <typename T> vector<T> MakeVec( const T& v1, const T& v2, const T& v3, const T& v4 ) {
	vector<T> v( MakeVec( v1, v2, v3 ) );
	v.push_back( v4 );
	return v;
}
template <typename T> vector<T> MakeVec( const T& v1, const T& v2, const T& v3, const T& v4, const T& v5 ) {
	vector<T> v( MakeVec( v1, v2, v3, v4 ) );
	v.push_back( v5 );
	return v;
}

string Join( const string& sep, const string& s1, const string& s2 ) { return Join( sep, MakeVec( s1, s2 ) ); }
string Join( const string& sep, const string& s1, const string& s2, const string& s3 ) { return Join( sep, MakeVec( s1, s2, s3 ) ); }
string Join( const string& sep, const string& s1, const string& s2, const string& s3, const string& s4 ) {
	return Join( sep, MakeVec( s1, s2, s3, s4 ) );
}
string Join( const string& sep, const string& s1, const string& s2, const string& s3, const string& s4, const string& s5 ) {
	return Join( sep, MakeVec( s1, s2, s3, s4, s5 ) );
}


//
// Function template: ToString
//
// A general method for converting arbitrary types to a human-readable
// string representation.
//
template <typename T>
inline string ToString( const T& v ) {
	std::ostringstream s;
	s << v;
	return s.str();
}

// Func: MakeValidIdentifier
// Replace any characters in the string that are not valid in a variable name, with underscores.
// Sequences of invalid chars are replaced by a single underscore.
// If the first character is not a letter, prepend an underscore.
string MakeValidIdentifier( const string& s ) {
	static const boost::regex invalidChar( "\\W+" );
	locale loc;
	string result( boost::regex_replace( s, invalidChar, "_" ) );
	if ( result.empty() || !std::use_facet< ctype<char> >( loc ).is( ctype<char>::alpha, result.at( 0 ) ) )
		 result = string("_") + result;
	return result;
}

double Frac( int a, int b ) { return double(a) / double(b); }

template <typename T> inline int isize( const vector<T>& v ) { return int( v.size() ); }

//
// End section: General utils
//

// Logical type: nchroms_t
// A count of chromosomes.
typedef int nchroms_t;

// Logical type: nsnps_t
// A count of SNPs.
typedef int nsnps_t;

// Logical type: loc_t
// A location of a SNP (represented as a fraction of the simulated region).
typedef double loc_t;

// Logical type: genid
// A generation (a time point).
typedef double genid;

// Logical type: prob_t
// A probability.
typedef double prob_t;

template <typename T>
T get_null() { throw std::logic_error( "unimpl" ); return T(); }

template <>
inline loc_t get_null<loc_t>() { return std::numeric_limits<loc_t>::quiet_NaN(); }
template <>
inline int get_null<int>() { return -1; }

template <typename T>
inline bool is_null( const T& val ) { return val == get_null<T>(); }

template <>
inline bool is_null<double>( const double& loc ) { return (boost::math::isnan)( loc ); }

// Logical type: len_t
// A length of a segment of the simulated region; a difference of two loc_t's.
typedef double len_t;

// Logical type: gens_t
// Length of a time interval, in generations.
typedef double gens_t;

//const loc_t NULL_LEN = std::numeric_limits<loc_t>::quiet_NaN();

// Logical type: snp_id_t;
// Identifies a specific SNP.
typedef int snp_id_t;

// Var: derCounts
// Number of derived alleles of each SNP.  Indexed by <snp_id>.
vector< nchroms_t > derCounts;

// Var: posit
// The location of each SNP
loc_t *posit;

//
// Class: ValRange
//
// A range of values.
//
template <typename T>
class ValRange {
public:
	 ValRange( T lwr = get_null<T>(), T upr = get_null<T>() ): bounds( make_pair( lwr, upr ) ) {}

	 void init( string rangeDef ) {
		 if ( !rangeDef.empty() ) {

			 typedef boost::tokenizer<boost::char_separator<char> > 
					tokenizer;
			 boost::char_separator<char> sep("-");
			 tokenizer tokens(rangeDef, sep);
			 vector<string> result( tokens.begin(), tokens.end() );

			 chk( result.size() == 1  ||  result.size() == 2 );
			 if ( result.size() == 1 ) {
				 bounds.first = bounds.second = boost::lexical_cast<T>( result.at(0) );
			 } else {
				 bounds.first = boost::lexical_cast<T>( result.at(0) );
				 bounds.second = boost::lexical_cast<T>( result.at(1) );
			 }
		 }
	 }

	 bool operator() ( T val ) const { return ( is_null( bounds.first ) || val >= bounds.first ) &&
				( is_null( bounds.second ) || val <= bounds.second ); }

	 T getMin() const { return bounds.first; }
	 T getMax() const { return bounds.second; }
	 
private:
	 // Field: bounds
	 // The pair of bounds of the range values
	 pair<T,T> bounds;
	 
};  // class ValRange

template <typename T>
ostream& operator<<( ostream& os, const ValRange<T>& valRange ) {
	if ( !is_null( valRange.getMin() ) ) os << valRange.getMin();
	if ( !is_null( valRange.getMax() ) && !( valRange.getMin() == valRange.getMax() ) ) os << "-" << valRange.getMax();
	
	return os;
}

//
// Class: SNPCond
//
// A condition on SNPs.
//
class SNPCond {
public:

	 void init( string locRangeDef ) { locRange.init( locRangeDef ); }

	 bool operator() ( snp_id_t snpId ) const {
		 return locRange( posit[ snpId ] );
	 }

	 string getColSfx() const { return ToString( locRange ); }

	 const ValRange<loc_t>& getLocRange() const { return locRange; }

private:
	 // Field: locRange
	 // Range of locations of SNPs satisfying this condition.
	 ValRange<loc_t> locRange;
	 
};  // class SNPFilter

ostream& operator<<( ostream& os, const SNPCond& snpCond ) {
	os << snpCond.getColSfx();
	return os;
}


//
// Class: AFS
//
// Allele frequency spectrum for a specified subset of SNPs.
//
class AFS {
public:

	 // class: Bin
	 // A bin of the allele frequency spectrum.
	 class Bin {
	 public:
			Bin(): nsnps( 0 ) {}

			Bin( string binDef ): nsnps( 0 ) { derCountRange.init( binDef ); }

			nchroms_t getMinDerCount() const { return derCountRange.getMin(); }
			nchroms_t getMaxDerCount() const { return derCountRange.getMax(); }

			const ValRange<nchroms_t>& getDerCountRange() const { return derCountRange; }

			void clear() { nsnps = 0; }
			void increment() { nsnps++; }
			nsnps_t getSnpCount() const { return nsnps; }

			string getColSfx() const { return ToString( derCountRange ); }

	 private:
			// Field: derCountRange
			// Range of derived-allele counts for SNPs going into this bin.
			ValRange<nchroms_t> derCountRange;
			
			// Field: nsnps
			// Number of SNPs in this bin
			nsnps_t nsnps;
			
	 };  // class Bin

	 // Method: init
	 // Initialize an AFS from a string definition.
	 // Definition looks like:
	 // 1,2,3-4
	 // 1,2,3-4;30000-40000
	 // The required part before semicolon specifies the bins.
	 // The optional part after the semicolon specifies the range of locations from which we take SNPs.
	 void init( const string& afsDef ) {

		 string binsDef, snpCondDef;
		 Split( afsDef, "/",  binsDef, snpCondDef );
		 snpCond.init( snpCondDef );
		 vector<string> binDefs = Split( binsDef, "," );
		 ForEach( string binDef, binDefs ) {
			 int binId = bins.size();
			 bins.push_back( Bin( binDef ) );
			 for ( nchroms_t nchroms = bins[ binId ].getMinDerCount(); nchroms <= bins[ binId ].getMaxDerCount(); nchroms++ ) {
				 if ( nchroms+1 >= isize( derCount2bin ) ) derCount2bin.resize( nchroms+2, -1 );
				 derCount2bin[ nchroms ] = binId;
			 }
		 }
	 }

	 void setSampleSize( nchroms_t nsam ) {
		 if ( nsam+1 >= isize( derCount2bin ) ) derCount2bin.resize( nsam+2, -1 );
	 }

	 void clear() { ForEach( Bin& bin, bins ) bin.clear(); }

	 void processSNP( snp_id_t snpId ) {
		 if ( snpCond( snpId ) ) {
			 nchroms_t derCount = derCounts[ snpId ];
			 chk( 0 <= derCount && derCount < int(derCount2bin.size()) );
			 int bin = derCount2bin[ derCount ];
			 if ( bin != -1 ) {
				 chk( 0 <= bin && bin < int(bins.size()) );
				 bins[ bin ].increment();
			 }
		 }
	 }

	 void writeHeadings( ostream& s ) const {
		 ForEach( const Bin& bin, bins )
				s << "\t" << MakeValidIdentifier( Join( "_", "afs", snpCond.getColSfx(), bin.getColSfx() ) );
	 }

	 void writeData( ostream& s, nsnps_t totSnps ) {
		 ForEach( const Bin& bin, bins ) {
			 s << "\t" << Frac( bin.getSnpCount(), totSnps); 
		 }
	 }

	 const vector<Bin>& getBins() const { return bins; }
	 const SNPCond& getSNPCond() const { return snpCond; }

	 const vector< int >& getDerCount2bin() const { return derCount2bin; }
   
	 
private:
	 // Field: bins
	 // All the bins of this AFS
	 vector< Bin > bins;

	 // Field: derCount2bin
	 // For each possible derived allele count, the corresponding bin in <bins>,
	 // or NULL if there is no bin for this count.
	 vector< int > derCount2bin;

	 // Field: snpCond
	 // Condition on SNPs going into this AFS
	 SNPCond snpCond;
	 
};  // class AFS

istream& operator>>( istream& is, AFS& afs );

istream& operator>>( istream& is, AFS& afs ) {
	string afsDef;
	is >> afsDef;
	afs.init( afsDef );
	
	return is;
}

ostream& operator<<( ostream& os, const AFS::Bin& bin );
ostream& operator<<( ostream& os, const AFS::Bin& bin ) {
	os << bin.getDerCountRange();
	return os;
}

ostream& operator<<( ostream& os, const AFS& afs );
ostream& operator<<( ostream& os, const AFS& afs ) {
	os << "[AFS: " << afs.getSNPCond() << " / " << afs.getBins() << "]";
	return os;
}

//
// Class: SNPPairCond
//
// A condition on pairs of SNPs.
//
class SNPPairCond {
public:
	 
	 // Method: init
	 // Initialize this SNP pair condition from a string definition.
	 // Syntax:
	 // .2-.3/snpcond1/snpcond2
	 void init( const string& def ) {
		 string lenRangeDef, snpCond1def, snpCond2def;
		 Split( def, "/", lenRangeDef, snpCond1def, snpCond2def );
		 lenRange.init( lenRangeDef );
		 snpConds[0].init( snpCond1def );
		 snpConds[1].init( snpCond2def );
	 }
	 
	 bool operator() ( snp_id_t snp1, snp_id_t snp2 ) const {
		 return lenRange( fabs( posit[ snp2 ] - posit[ snp1 ] ) ) &&
				( ( snpConds[0]( snp1 ) && snpConds[1]( snp2 ) ) ||
					( snpConds[0]( snp2 ) && snpConds[1]( snp1 ) ) )
					;
	 }
	 
	 const ValRange<len_t>& getLenRange() const { return lenRange; }
	 const SNPCond& getSnpCond1() const { return snpConds[0]; }
	 const SNPCond& getSnpCond2() const { return snpConds[1]; }
	 
private:
	 // Field: lenRange
	 // Range physical distances for SNP pairs in the set.
	 ValRange<len_t> lenRange; 
	 
	 // Field: snpConds
	 // Conditions that must be satisfied by the two SNPs.
	 SNPCond snpConds[2];
	 
};  // class SNPPairCond

ostream& operator<<( ostream& os, const SNPPairCond& pairCond );
ostream& operator<<( ostream& os, const SNPPairCond& pairCond ) {
	os << Join( "_", ToString( pairCond.getLenRange() ), ToString( pairCond.getSnpCond1() ), ToString( pairCond.getSnpCond2() ) );
	return os;
}

namespace acc = boost::accumulators;
// using acc::acumulator_set;
// using acc::tag;
// using acc::stats;
// using acc::mean;
// using acc::variance;
// using acc::sum_kahan;
//using acc::extract;

typedef acc::accumulator_set<double, acc::stats< acc::tag::sum_kahan, acc::tag::mean, acc::tag::variance > > acc_t;

//
// Class: LD
//
// A subset of the possible SNP pairs, and LD info for it.
//
class LD {
	 
	 
public:
	 
	 void init( string def ) { pairCond.init( def ); }
	 
	 void clear() {
		 r2_stats = acc_t( acc::extended_p_square_probabilities = quantile_probs );
		 Dprime_stats = acc_t( acc::extended_p_square_probabilities = quantile_probs );
	 }
	 
	 const SNPPairCond& getPairCond() const { return pairCond; }
	 
	 void writeHeadings( ostream& s ) const {
		 vector<string> statNames = MakeVec<string>( "mean", "var", "count", "sum" );
		 
		 for ( int which = 0; which < 2; which++ ) {
			 ForEach( string statName, statNames ) {
				 string accName = ( which == 0 ? "r2" : "Dprime" );
				 s << "\t" << MakeValidIdentifier( Join( "_", "ld", ToString( pairCond ), accName, statName ) );
			 }
		 }
	 }
	 
	 void writeData( ostream& s ) const {
		 for ( int which = 0; which < 2; which++ ) {
			 const acc_t *accum = ( which == 0 ? &r2_stats : &Dprime_stats );
			 s << "\t" << acc::mean( *accum ); 
			 s << "\t" << acc::variance( *accum ); 
			 s << "\t" << acc::extract::count( *accum ); 
			 s << "\t" << acc::sum_kahan( *accum ); 
		 }
	 }
	 
	 const SNPPairCond& getSNPPairCond() const { return pairCond; }

	 void processSNPPair( snp_id_t snp1, snp_id_t snp2, nchroms_t nsam, char **snps ) {
		 // if ( ( fabs( posit[snp1] - .5 ) < 1e-5  ||
		 // 				fabs( posit[snp2] - .5 ) < 1e-5 ) )
		 if ( pairCond( snp1, snp2 ) ) {
			 double r2, Dprime;
			 if ( compute_LD( snp1, snp2, nsam, snps, &r2, &Dprime ) ) {
				 r2_stats( r2 );
				 Dprime_stats( Dprime );
			 }
		 }
	 }
	 
private:
	 // Field: pairCond
	 // Condition that must be satisfied by SNP pairs in the set
	 SNPPairCond pairCond;


	 // Field: r2_stats
	 // Statistics on r2 for SNP pairs in the set.
	 acc_t r2_stats;

	 // Field: Dprime_stats
	 // Statistics on D' for SNP pairs in the set.
	 acc_t Dprime_stats;

	 static const vector<prob_t> quantile_probs;
	 
};  // class LD

const vector<prob_t> LD::quantile_probs = boost::assign::list_of(.1)(.5)(.9);

istream& operator>>( istream& is, LD& ld );
istream& operator>>( istream& is, LD& ld ) {
	string ldDef;
	is >> ldDef;
	ld.init( ldDef );
	return is;
}

ostream& operator<<( ostream& os, const LD& ld );
ostream& operator<<( ostream& os, const LD& ld ) {
	os << ld.getPairCond();
	return os;
}

class TreeEdge {
public:
	 TreeEdge( const char *line ) {
				chk( sscanf( line, "ARG %lf %lf %lf %lf %d", &beg, &end, &genMoreRecent, &genLessRecent, &leafsetSize ) == 5 );
	 }

	 bool containsLoc( loc_t loc ) const { return beg <= loc && loc <= end; }
	 
	 loc_t beg;
	 loc_t end;
	 genid genMoreRecent;
	 genid genLessRecent;
	 nchroms_t leafsetSize;
};

//
// Class: TreeEdgeSet
//
// Gather stats for a collection of tree edges
//
class TreeEdgeSet {
public:
	 typedef boost::function<bool (const TreeEdge& treeEdge)> treeEdgePred_t;
	 
	 TreeEdgeSet( treeEdgePred_t pred_, string predName_ ): pred( pred_ ), predName( predName_ ) { clear(); }

	 void processTreeEdge( const TreeEdge& treeEdge ) {
		 if ( pred( treeEdge ) ) {

			 len_t segLen = treeEdge.end - treeEdge.beg;
			 gens_t edgeGens = treeEdge.genLessRecent - treeEdge.genMoreRecent;
			 
			 mutimes( segLen * edgeGens );
			 lens( segLen );
			 gens( edgeGens );
			 
			 maxTreeHeight = std::max( maxTreeHeight, treeEdge.genLessRecent );
		 }
	 }

	 void writeHeadings( ostream& s ) const {
		 s << "\t" << "treeEdge_" << predName << "_n";
		 vector<string> statNames = MakeVec<string>( "mutime", "len", "gens" );
		 vector<string> summNames = MakeVec<string>( "sum", "mean", "var" );
		 ForEach( string statName, statNames ) {
				ForEach( string summName, summNames ) {
					s << "\t" << MakeValidIdentifier( Join( "_", "treeEdge", predName, statName, summName ) );
				}
		 }
		 s << "\t" << "treeEdge_" << predName << "_maxTreeHeight";
	 }

	 void writeData( ostream& s ) const {
		 s << "\t" << acc::count( mutimes );

		cout << "\t" << acc::sum_kahan( mutimes ) << "\t" << acc::mean( mutimes ) << "\t" << acc::variance( mutimes );
		cout << "\t" << acc::sum_kahan( lens ) << "\t" << acc::mean( lens ) << "\t" << acc::variance( lens );
		cout << "\t" << acc::sum_kahan( gens ) << "\t" << acc::mean( gens ) << "\t" << acc::variance( gens );

		cout << "\t" << maxTreeHeight;
	 }

	 void clear() {
		 mutimes = acc_t();
		 lens = acc_t();
		 gens = acc_t();
		 maxTreeHeight = 0;
	 }

private:
	 treeEdgePred_t pred;
	 string predName;
	 
	 acc_t mutimes, lens, gens;

	 double maxTreeHeight;
	 
};  // class TreeEdgeSet


//////////////////////////////////////////

bool StartsWith( const char *s, const char *pfx ) { return strlen( s ) >= strlen( pfx ) && !strncmp( s, pfx, strlen( pfx ) ); }

int  segsub( int nsam, int segsites, char **list ) ;


int sample_stats_main(int argc, char *argv[])
{
	int nsam, i,  howmany  ;
	const size_t MAX_LINE_LEN = 8191;
	char **list, line[MAX_LINE_LEN+1];
	FILE *pfin ;
	nsnps_t   segsites;
	int count;
	double pi , h, th  ,prob ;
	char dum[20], astr[100] ;
	int precision(8);

	vector< pair< double, double > > snpPairDists;

	len_t MARGIN(0.0);
	
	cerr.precision(8);

	namespace po = boost::program_options;

	vector<AFS> AFSs;
	vector<LD> LDs;
	vector<TreeEdgeSet> treeEdgeSets;
	
	po::positional_options_description positional_opts;
	
	po::options_description desc("Allowed options");
	desc.add_options()
		 ("help,h", "produce help message")
		 ("precision,p", po::value(&precision)->default_value(8), "specify precision of output")
		 ("margin,m", po::value(&MARGIN)->default_value(.1), "ignore part of simulated region within this margin of ends of region")
		 ("afs,a", po::value(&AFSs)->composing(), "compute allele frequency spectrum")
		 ("ld,l", po::value(&LDs)->composing(), "compute LD stats for these definitions")
		 ;
	
	po::variables_map vm;
	try {
		po::store(po::command_line_parser(argc, argv).options(desc).positional(positional_opts).run(), vm);
		po::notify(vm);    
	} 
	catch(std::exception& e) {
		cerr << e.what() << "\n";
		return EXIT_FAILURE;
	}

	if ( vm.count( "help" ) ) { cerr << desc; return EXIT_FAILURE; }

	cout.precision( precision );

	treeEdgeSets.push_back( TreeEdgeSet( phx::val(true), "all" ) );
	treeEdgeSets.push_back( TreeEdgeSet( phx::bind( &TreeEdge::containsLoc, arg1, .5 ), "mid" ) );
	treeEdgeSets.push_back( TreeEdgeSet( phx::bind( &TreeEdge::genMoreRecent, arg1 ) == 0, "bot" ) );
	treeEdgeSets.push_back( TreeEdgeSet( phx::bind( &TreeEdge::genMoreRecent, arg1 ) == 0 && phx::bind( &TreeEdge::containsLoc, arg1, .5 ), "botmid" ) );

	// chk( ( argc & 1 ) );

	// double MARGIN = getVal<double>( argv[1] );
	// int afsMax = getVal<int>( argv[2] );
	
	// for ( int ni = 3; ni < argc; ni+=2 )
	// 	snpPairDists.push_back( make_pair( getVal<double>( argv[ni] ), getVal<double>( argv[ni+1] ) ) );


/* read in first two lines of output  (parameters and seed) */
  pfin = stdin ;
  chk( fgets( line, MAX_LINE_LEN, pfin) );
  chk( sscanf(line," %s  %d %d", dum,  &nsam, &howmany) == 3 );
  chk( fgets( line, MAX_LINE_LEN, pfin) );


  list = cmatrix(nsam,maxsites+1);
	char **trimmed_list = ( char **)malloc( nsam * sizeof( char * ) );
  posit = (loc_t *)malloc( maxsites*sizeof( loc_t ) ) ;

	chk( trimmed_list && posit );

	vector<string> statNames;

  count=0;
	while( howmany-count++ ) {

		//
		// Find the beginning of one simulation.  Simulations begin with
		// a double forward slash at the beginning of a line.
		//
		do { chk( fgets( line, MAX_LINE_LEN, pfin) ); }
		while ( !StartsWith( line, "//" ) );

		//
		// Read statistics gathered for the simulation, and/or ARG edges
		// output for this simulation.
		//


		int statIdx = 0;
		vector<double> statVals;
		set<loc_t> recombLocs, recombBegs, recombEnds;

		ForEach( TreeEdgeSet& treeEdgeSet, treeEdgeSets ) treeEdgeSet.clear();
		
		while( true ) {
			chk( fgets( line, MAX_LINE_LEN, pfin) );

			if ( StartsWith( line, "segsites:" ) )
				 break;
			else if( StartsWith( line, "prob:" ) ) {
				chk( sscanf( line, "  prob: %lf", &prob ) == 1 );
			} else if ( StartsWith( line, "ARG" ) ) {

				TreeEdge treeEdge( line );

				ForEach( TreeEdgeSet& treeEdgeSet, treeEdgeSets ) treeEdgeSet.processTreeEdge( treeEdge );
				
				recombLocs.insert( treeEdge.beg );
				recombLocs.insert( treeEdge.end );
				recombBegs.insert( treeEdge.beg );
				recombEnds.insert( treeEdge.end );

			} else if ( StartsWith( line, "stat " ) ) {
				string dummy, statName;
				double statVal;
				istringstream istrm( line );
				istrm >> dummy >> statName >> statVal;
				if ( count == 1 )
					 statNames.push_back( statName );
				else
					 chk( statNames.at( statIdx++ ) == statName );
				statVals.push_back( statVal );
			} else
				 throw std::logic_error( string("unknown input line: ") + string( line ) );
		}
		
		chk( sscanf( line, "  segsites: %d", &segsites ) == 1 );
		if( segsites >= maxsites){
			maxsites = segsites + 10 ;
			posit = (loc_t *)realloc( posit, maxsites*sizeof( loc_t ) ) ;
			chk( posit );
			biggerlist(nsam,maxsites, list) ;
		}

		int first_snp = 0, last_snp = segsites-1, trimmed_segsites = segsites;
		const loc_t *trimmed_posit = posit;


		{
			if ( segsites > 0 ) {
				chk( fscanf(pfin," %s", astr) == 1 );
				chk( !strcmp( astr, "positions:" ) );
				for( i=0; i<segsites ; i++) {
					chk( fscanf(pfin," %lf",posit+i) == 1 && 0.0 <= *(posit+i) && *(posit+i) <= 1.0 );
				}
			}
			first_snp = 0;
			while( first_snp < segsites && posit[ first_snp ] < MARGIN ) first_snp++;
			last_snp = segsites-1;
			while( last_snp > first_snp && posit[ last_snp ] > ( 1.0 - MARGIN ) ) last_snp--;

			//chk( 0 <= first_snp && first_snp < last_snp && last_snp < segsites );
			
			trimmed_segsites = last_snp - first_snp + 1;
			
			trimmed_posit = posit + first_snp;
			derCounts.clear();
			derCounts.resize( trimmed_segsites, 0 );

			if ( segsites > 0 ) {
				
				for( i=0; i<nsam;i++) {
					chk( fscanf(pfin," %s", list[i] ) == 1 && int( strlen( list[i] ) ) == segsites );
					trimmed_list[ i ] = list[ i ] + first_snp;
					
					size_t num = trimmed_segsites;
					const char *p = trimmed_list[ i ];
					while( const char *p_new = (const char *)memchr( p, '1', num ) ) {
						chk( *p_new == '1' );
						chk( size_t( p_new - p ) <= num );
						num -= ( p_new - p );
						int snpId = p_new - trimmed_list[i];
						chk( 0 <= snpId && snpId < trimmed_segsites );
						derCounts[ snpId ]++;
						p = p_new+1;
						if ( num >= 1 ) num--;
					}
				}  // read each sample
				
				//	 list[i][ last_snp+1 ] = '\0';
			}  // if ( segsites > 0 )
		}
		/* analyse sample ( do stuff with segsites and list) */


		if ( count == 1 ) {
			cout << "pi\tss\tD\ttheta\tH\tnrecombLocs\tnrecombBegs\tnrecombEnds";
			ForEach( string statName, statNames ) {
				 cout << "\t" << statName;
			}

			ForEach( const TreeEdgeSet& treeEdgeSet, treeEdgeSets ) {
				treeEdgeSet.writeHeadings( cout );
			}

			ForEach( AFS& afs, AFSs ) {
				afs.writeHeadings( cout );
				afs.setSampleSize( nsam );
			}
			ForEach( const LD& ld, LDs ) ld.writeHeadings( cout );
			cout << "\n";
		}

		double tajd_val( 0.0 );

		pi = nucdiv(nsam, trimmed_segsites, trimmed_list) ;
		h = hfay(nsam, trimmed_segsites, trimmed_list) ;
		th = thetah(nsam, trimmed_segsites, trimmed_list) ;
		tajd_val = tajd(nsam,trimmed_segsites,pi);
		
		cout << pi << "\t" << trimmed_segsites << "\t" << tajd_val << "\t"
				 << th << "\t" << h << "\t" << recombLocs.size() << "\t" << recombBegs.size() << "\t" << recombEnds.size();

		ForEach( double statVal, statVals ) cout << "\t" << statVal;

		ForEach( const TreeEdgeSet& treeEdgeSet, treeEdgeSets ) treeEdgeSet.writeData( cout );

		// compute AFS

		ForEach( AFS& afs, AFSs ) {
			afs.clear();
			for ( snp_id_t ii = 0; ii < trimmed_segsites; ii++ )
				 afs.processSNP( ii );
			afs.writeData( cout, trimmed_segsites );
		}

		// compute LD stats
		ForEach ( LD& ld, LDs ) {
			ld.clear();
			ValRange<len_t> lenRange = ld.getSNPPairCond().getLenRange();
			int snp2 = 1;
			for ( int snp1 = 0; snp1 < trimmed_segsites; snp1++ ) {
				while( snp2 < trimmed_segsites && ( snp2 <= snp1 || trimmed_posit[snp2]-trimmed_posit[snp1] < lenRange.getMin() ) )
					 snp2++;
				int snp2_tmp = snp2;
				while( snp2_tmp < trimmed_segsites && trimmed_posit[snp2_tmp]-trimmed_posit[snp1] < lenRange.getMax() ) {
					chk( snp1 != snp2_tmp );
					ld.processSNPPair( snp1, snp2_tmp, nsam, trimmed_list );
					snp2_tmp++;
				}
			}
			ld.writeData( cout );
		}

		cout << "\n";
		
  }
	free_cmatrix( list, nsam );
	free( trimmed_list );
	free( posit );
	return EXIT_SUCCESS;
}

	

/* allocates space for gametes (character strings) */
char **
cmatrix(int nsam,int len)
{
	int i;
	char **m;

	if( ! ( m = (char **) malloc( (unsigned)( nsam*sizeof( char* )) ) ) ) {
	   perror("alloc error in cmatrix") ;
		 chk( m );
	}
	for( i=0; i<nsam; i++) {
		if( ! ( m[i] = (char *) malloc( (unsigned) (len*sizeof( char )) ))) {
			 perror("alloc error in cmatric. 2");
			 chk( m[i] );
		}
	}
	return( m );
}

void free_cmatrix(char **cm, nchroms_t nsam ) {
	for ( int i = 0; i < nsam; i++ )
		 free( cm[ i ] );
	free( cm );
}

void
biggerlist(int nsam, unsigned nmax, char **list )
{
	int i;

	maxsites = nmax  ;
	for( i=0; i<nsam; i++){
		chk( ( list[i] = (char *)realloc( list[i],maxsites*sizeof(char) ) ) );
	}
}                        


double
nucdiv( int nsam, int segsites, char **list)
{
	int s, frequency( char, int, int, char**);
	double pi, p1, nd, nnm1  ;

	pi = 0.0 ;

	nd = nsam;
	nnm1 = nd/(nd-1.0) ;
	for( s = 0; s <segsites; s++){
		p1 = frequency('1', s,nsam,list)/nd ;
		pi += 2.0*p1*(1.0 -p1)*nnm1 ;
	}
	return( pi ) ;
}

/*   thetah - pi   */
double
hfay( int nsam, int segsites, char **list)
{
	int s, frequency( char, int, int, char**);
	double pi, p1, nd, nnm1  ;

	pi = 0.0 ;

	nd = nsam;
	nnm1 = nd/(nd-1.0) ;
	for( s = 0; s <segsites; s++){
		p1 = frequency('1', s,nsam,list)/nd ;
		pi += 2.0*p1*(2.*p1 - 1.0 )*nnm1 ;
	}
	return( -pi ) ;
}

/* Fay's theta_H  */
double
thetah( int nsam, int segsites, char **list)
{
	int s, frequency( char, int, int, char**);
	double pi, p1, nd /*, nnm1*/  ;

	pi = 0.0 ;

	nd = nsam;
	//nnm1 = nd/(nd-1.0) ;
	for( s = 0; s <segsites; s++){
		p1 = frequency('1', s,nsam,list) ;
		pi += p1*p1 ; 
	}
	return( pi*2.0/( nd*(nd-1.0) )  ) ;
}


int
frequency( char allele,int site,int nsam,  char **list);

void get_freqs( int site_i, int site_j, int nsam, char **list,
								double *p_i, double *p_j, double *p_ij );
int
frequency( char allele,int site,int nsam,  char **list)
{
	int i, count=0;
	for( i=0; i<nsam; i++) count += ( list[i][site] == allele ? 1: 0 ) ;
	return( count);
}

void get_freqs( int site_i, int site_j, int nsam, char **list,
								double *p_i, double *p_j, double *p_ij ) {

	int n_ij = 0;
	for ( int s = 0; s < nsam; s++ ) {
		bool i_der = ( list[s][site_i] == '1' );
		bool j_der = ( list[s][site_j] == '1' );
		if ( i_der && j_der ) n_ij++;
	}
	int n_i = derCounts[ site_i ];
	int n_j = derCounts[ site_j ];

	*p_i = double( n_i ) / double( nsam );
  *p_j = double( n_j ) / double( nsam );
	*p_ij = double( n_ij ) / double( nsam ); 
}

bool compute_LD( int site_i, int site_j, int nsam, char **list,
								 double *r2, double *Dprime ) {
	double p_i, p_j, p_ij;
	get_freqs( site_i, site_j, nsam, list, &p_i, &p_j, &p_ij );
	double D = p_ij - p_i * p_j;
	double D_max = ( D > 0 ) ? p_i*p_j : std::min( p_i * ( 1 - p_j ), p_j * ( 1 - p_i ) );
	if ( p_i == 0 || p_j == 0 ) {
		*Dprime = std::numeric_limits<cosi_double>::quiet_NaN();
		*r2 = std::numeric_limits<cosi_double>::quiet_NaN();
		return false;
	} else {
		*Dprime = D / D_max;
		*r2 = D * D / ( p_i * ( 1-p_i ) * p_j * ( 1 - p_j ) );
		return true;
	}
}



int
segsub( int nsub, int segsites, char **list )
{
	int i, count = 0 , c1 ;
	int frequency( char, int, int, char**) ;

	for(i=0; i < segsites ; i++){
	  c1 = frequency('1',i,nsub, list);
	  if( ( c1 > 0 ) && ( c1 <nsub )  ) count++;
	}
	return( count ) ;
}

	
}  // namespace ms

int main( int argc, char *argv[] ) { return cosi::sample_stats_main( argc, argv ); }

#ifdef __GNUC__
#if ( __GNUC__ > 4 ) || ( ( __GNUC__ == 4 ) && ( __GNUC_MINOR__ > 5 ) )
#pragma GCC diagnostic pop
#endif
#endif

