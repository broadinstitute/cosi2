//
// Program: cosimain
//
// The top-level executable for the cosi simulator.
// Parses command-line args, and invokes the cosi library to run the simulation.
//

#include <cstdlib>
#include <sstream>
#include <boost/program_options.hpp>
#include <cosi/defs.h>
#include <cosi/demography.h>
#include <cosi/recomb.h>
#include <cosi/genmap.h>
#include <cosi/mutlist.h>
#include <cosi/mutate.h>
#include <cosi/cositop.h>
#include <cosi/file.h>

namespace cosi {

using util::ToString;
	
CoSiMain::CoSiMain():
	deltaTfactor( 1.0 ),
	msOutput( False ), outputMutGens( False ), outputRecombLocs( False ), segfp( NULL ), logfp( NULL ), len_length(-1),
	sim_only( False ), showProgress( False ), verbose( False ), treeSizeOnly( False ), nsims( 1 ),
	showNumRecombs( False ), outputTreeStats( False ), outputPrecision( 6 ),
	maxCoalDist( 1.0 ), maxCoalDistCvxHull( False ) {
}

void
CoSiMain::printusage (void)
{
	fprintf(stderr, "usage: ");
	fprintf(stderr, "coalescent -p param_file ");
	fprintf(stderr, "[-l logfile] [-s segfile]\n");
  
	exit (EXIT_FAILURE);
}

int
CoSiMain::parse_args( int argc, char *argv[] ) {
	using std::cout;
  using std::vector;
	using std::string;
	using std::istringstream;

	namespace po = boost::program_options;

	string prog( argv[0] );

	po::options_description main_options( "Specifying the model" );
	main_options.add_options()
		 ( "paramfile,p", po::value(&paramfile)->required(), "parameter file" )
		 ( "trajfile,J", po::value(&trajFN), "file from which to read sweep trajectory" )
		 ( "nsims,n", po::value(&nsims)->default_value(1), "number of simulations to output" );

	po::options_description output_options( "Specifying the output format" );
	output_options.add_options()
		 ( "outfilebase,o", po::value(&outfilebase), "base name for output files in cosi format" )
		 ( "outms,m", po::bool_switch(&msOutput), "write output to stdout in ms format" );

	po::options_description output_details_options( "Specifying output details" );
	output_details_options.add_options()
		 ( "output-precision,P", po::value( &outputPrecision ), "number of decimal places used for floats in the outputs" )
		 ( "trajoutfile,j", po::value(&trajOutFN), "file to which to output sweep trajectory" )
		 
		 ( "write-tree-stats,T", po::bool_switch(&outputTreeStats), "output tree stats" )
		 ( "write-mut-ages,M", po::bool_switch(&outputMutGens), "output mutation ages" )
		 ( "write-recomb-locs,L", po::bool_switch(&outputRecombLocs), "output recombination locations" )
		 ( "write-mut-contexts,C", po::value(&outputMutContextsFor)->value_name( "position" ),
			 "output mutation contexts for these locations" );

	po::options_description misc_options( "Misc options" );
	misc_options.add_options()
		 ( "help,h", "produce help message" )
		 ( "verbose,v", po::bool_switch(&verbose), "verbose output" )
		 ( "show-progress,g", po::bool_switch( &showProgress ), "show progress" );

	po::options_description dev_options( "Developer options" );
	dev_options.add_options()
		 ( "logfile,l", po::value(&logfile), "log file" )
		 ( "segfile,s", po::value(&segfile), "seg file" )

		 ( "max-coal-dist,u", po::value(&maxCoalDist), "max dist betw segs for coalescence" )
		 ( "max-coal-dist-cvx-hull,U", po::bool_switch(&maxCoalDistCvxHull), "use convex hull for max coal dist" )
		 
		 ( "deltaTfactor,d", po::value(&deltaTfactor)->default_value(factor_t(1.0)), "delta factor for sweep" )

		 ( "tree-size-only,t", po::bool_switch(&treeSizeOnly), "compute tree size only" )
		 ( "show-num-recombs,k", po::bool_switch(&showNumRecombs), "print number of recombs" )
		 ( "sim-and-quit,S", po::bool_switch(&sim_only), "do simulation and quit" )
		 ;

	po::options_description cosi_options;
	cosi_options.add( main_options ).add( output_options ).add( output_details_options ).add( misc_options ).add( dev_options );

	if ( argc == 1 ) {
    cout << cosi_options << "\n";
    return EXIT_FAILURE;
	}

	po::variables_map vm;
	po::store(po::parse_command_line(argc, argv, cosi_options), vm);
	
	po::notify(vm);

	if (vm.count("help")) {
    cout << cosi_options << "\n";
    return EXIT_FAILURE;
	}

	if (!segfile.empty()) {
		if ((segfp = fopen(segfile.c_str(), "w")) == NULL) {
			fprintf(stderr, 
							"ERROR %s: cannot open file %s for writing\n",
							prog.c_str(), 
							segfile.c_str());
			exit (EXIT_FAILURE);
		}
	}
			 
	else segfp = NULL;
			 
	if (!logfile.empty()) {
		if ((logfp = fopen(logfile.c_str(), "w")) == NULL) {
			fprintf(stderr, 
							"ERROR %s: cannot open file %s for writing\n",
							prog.c_str(), logfile.c_str());
			exit(EXIT_FAILURE);
		}
	}
	else logfp = NULL;

	return EXIT_SUCCESS;
}  // CoSiMain::parse_args

int 
CoSiMain::cosi_main(int argc, char *argv[]) {

	if ( parse_args( argc, argv ) == EXIT_FAILURE ) return EXIT_FAILURE;

	PRINT( nsims );
	RandGenP randGen;
	for ( int simNum = 0; simNum < nsims; simNum++ ) {
		PRINT( simNum );
		CoSi cosi;

		cosi.set_segfp( segfp );
		cosi.set_logfp( logfp );
		cosi.set_verbose( verbose );
		cosi.set_trajFN( trajFN );
		cosi.set_trajOutFN( trajOutFN );
		cosi.set_outputTreeStats( outputTreeStats );
		cosi.set_outputMutGens( outputMutGens );
		cosi.set_outputRecombLocs( outputRecombLocs );
		cosi.set_deltaTfactor( deltaTfactor );
		cosi.set_maxCoalDist( plen_t( maxCoalDist ) );
		cosi.set_maxCoalDistCvxHull( maxCoalDistCvxHull );

		if ( simNum == 0 ) {
			cosi.setUpSim( paramfile );
			randGen = cosi.getRandGen();
			if ( !msOutput ) std::cerr << "coalescent seed: " << randGen->getSeed() << "\n";
			if ( msOutput ) {
				std::cout << "ms " << cosi.getDemography()->getTotSamples() << " " << nsims << "\n";
				std::cout << "cosi_rand " << randGen->getSeed() << "\n\n";
			}
		} else
			 cosi.setUpSim( paramfile, randGen );

		using boost::make_shared;
		MutlistP muts = make_shared<Mutlist>();
		cosi.setMutProcessor( make_shared<MutProcessor_AddToMutlist>( muts ) );

		if ( msOutput ) cout << "// seed=" << randGen->getSeed() << endl;
	
		ParamFileReaderP params = cosi.getParams();
		cosi.runSim();

		if ( showNumRecombs ) { PRINT( cosi.getRecomb()->getNumRecombs() ); }

		if ( msOutput || !outfilebase.empty() ) {
			PRINT( "freezing" );
			muts->freeze( params->getInfSites() || msOutput, params->getGenMap()->recomb_get_length() );
			PRINT( "frozen" );
			
			if (!msOutput && !outfilebase.empty()) {
				string fbase( outfilebase.native() + ( nsims == 1 ? ToString( "" ) :
																							 ToString( "_" ) + ToString( simNum ) ) );
				 print_haps( cosi.getDemography(), fbase,
										 params->getLength(), muts,
										 params->getInfSites() );
#ifdef COSI_DEV_MUTCONTEXT				 
				 if ( !outputMutContextsFor.empty() )
						print_mut_contexts( cosi.getDemography(), fbase, params->getLength(),
																mutcontext::getSavedMutContexts() );
#endif				 
			}
			
			if ( msOutput ) 
				 muts->print_haps_ms( std::cout, cosi.getDemography()->getSampleSizes(), cosi.getTreeStatsHook(),
															cosi.get_outputMutGens(),
															outputRecombLocs ? &(cosi.getRecombRecorder()->getRecombLocs()) : NULL,
															outputPrecision );
		}
		if ( showProgress && !( simNum % 100 ) ) { PRINT( simNum ); }
		
	}

	if ( segfp ) fclose( segfp );
	if ( logfp ) fclose( logfp );
	
  return EXIT_SUCCESS;
}

}  // namespace cosi
