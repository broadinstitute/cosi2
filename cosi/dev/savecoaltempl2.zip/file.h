/* $Id: file.h,v 1.3 2011/05/04 15:46:19 sfs Exp $ */
#ifndef __INCLUDE_COSI_FILE_H
#define __INCLUDE_COSI_FILE_H
#include <cstdio>
#include <string>
#include <boost/filesystem.hpp>
#include <cosi/defs.h>
#include <cosi/decls.h>
#include <cosi/geneconversion.h>

namespace cosi {

//
// Class: ParamFileReader
//
// Parses cosi <parameter files>, calls on other objects (notably <Demography> and <HistEvents>)
// as needed to construct a programmatic representation of the demographic model
// to be simulated, and stores some parameters inside itself for later retrieval.
//
class ParamFileReader {
public:
	 ParamFileReader( DemographyP demography_ );

	 // MethodP: file_read
	 // Parse the specified parameter file.
	 void file_read( boost::filesystem::path filename, FILE *segfp );
	 
	 GenMapP getGenMap() const { return genMap; }
	 unsigned long getRandomSeed() const { return rseed; }
	 len_bp_int_t getLength() const { return length; }
	 prob_per_bp_per_gen_t getMu() const { return mu; }
	 double getGeneConversionRate() const { return geneConversionRate; }
	 factor_t getGeneConv2RecombRateRatio() const { return geneConv2RecombRateRatio; }
	 len_bp_int_t getGeneConversionMeanTractLength() const { return geneConversionMeanTractLength; }
	 len_bp_int_t getGeneConversionMinTractLength() const { return geneConversionMinTractLength; }
	 GeneConversion::GCModel getGeneConversionModel() const { return geneConversionModel; }
	 HistEventsP getHistEvents() const { return histEvents; }
	 bool_t getInfSites() const { return infSites; }

	 void setPrintSeed( bool_t printSeed_ ) { printSeed = printSeed_; }

	 unsigned long getRandSeed() const { return rseed; }
	 bool_t isSeeded() const { return seeded; }

	 popid getIgnoreRecombsInPop() const { return this->ignoreRecombsInPop; }
	 
private:
	 // Field: demography
	 // The current state of the simulation.  As the parameter file is parsed,
	 // this object is initialized to the initial state of the simulation.
	 DemographyP demography;

	 // Field: seeded
	 // Whether a random seed has been specified in the parameter file.
	 bool_t seeded;

	 
	 int popsize;
	 int sampsize;
	 len_bp_int_t length;
	 prob_per_bp_per_gen_t mu;
	 double recombrate;
	 double geneConversionRate;
	 factor_t geneConv2RecombRateRatio;
	 len_bp_int_t geneConversionMeanTractLength;
	 len_bp_int_t geneConversionMinTractLength;
	 GeneConversion::GCModel geneConversionModel;
	 // Private field: rseed
	 // The random seed, if specified in the parameter file. 
	 unsigned long rseed;
	 GenMapP genMap;
	 HistEventsP histEvents;
	 bool_t infSites;
	 bool_t printSeed;
	 popid ignoreRecombsInPop;
	 boost::filesystem::path paramFileName;

	 void init();
	 int file_get_data (FILE * fileptr, FILE *);
	 int file_proc_buff(char * var, char* buffer, FILE*);
	 int file_killwhitespace(FILE * fileptr);
	 void file_proc_recombfile (const char*  filename);
	 void file_exit(const char* , const char*);
	 void file_error_nonfatal(const char* , const char*);
};

typedef boost::shared_ptr<ParamFileReader> ParamFileReaderP;

}  // namespace cosi

#endif
