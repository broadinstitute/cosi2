#ifndef __COSI_INCLUDE_COSITOP_H
#define __COSI_INCLUDE_COSITOP_H

#include <string>
#include <cosi/coalescent.h>
#include <cosi/output.h>
#include <cosi/cosirand.h>

namespace cosi {

using std::string;

//
// Class: CoSiMain
//
// The top-level CoSi program.  Handles parsing of command-line, and invoking
// the simulator.
//
class CoSiMain {
public:
	 CoSiMain();
	 int cosi_main( int argc, char *argv[] );
	 
private:
	 filename_t paramfile, segfile, logfile, outfilebase, trajOutFN;

	 // Field: trajFN
	 // If non-empty, the name of the file from which to load the trajectory of the causal allele
	 // for use during selected <Sweep>.
	 string trajFN;

	 // Field: deltaTfactor
	 // Factor by which to multiply deltaT (step size) during sweep simulation.
	 factor_t deltaTfactor;
	 
	 // Field: msOutput
	 // Whether to produce output in ms simulator format, written to stdout,
	 // or in cosi format, written to separate .pos and .hap files for each population.
	 bool_t msOutput;

	 // Field: outputMutGens
	 // Whether to output mutation times.
	 bool_t outputMutGens;

	 // Field: outputRecombLocs
	 // Whether to output recombination locations
	 bool_t outputRecombLocs;
	 
	 FILE *segfp, *logfp;
	 len_bp_int_t len_length;
	 bool_t sim_only;
	 bool_t showProgress;
	 bool_t verbose;
	 bool_t treeSizeOnly;
	 int nsims;
	 bool_t showNumRecombs;

	 // Field: outputTreeStats
	 // Output tree statistics, when writing out ms format.
	 bool_t outputTreeStats;

	 // Field: outputPrecision
	 // Number of decimal places in the output
	 int outputPrecision;

	 // Field: outputMutContextsFor
	 // Mutations for which to output the context
	 vector< loc_bp_int_t > outputMutContextsFor;

	 double maxCoalDist;
	 bool maxCoalDistCvxHull;
	 
	 void printusage();
	 int parse_args( int argc, char *argv[] );
};  // class CoSiMain


}  // namespace cosi

#endif  // __COSI_INCLUDE_COSITOP_H
