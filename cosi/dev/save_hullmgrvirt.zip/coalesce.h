//
// Header: coalesce.h
//
// Keeping track of coalescence probabilities, and choosing coalescent events.

/* $Id: coalesce.h,v 1.2 2011/05/03 18:50:54 sfs Exp $ */
#ifndef __COSI_INCLUDE_COALESCE_H
#define __COSI_INCLUDE_COALESCE_H

#include <functional>
#include <cosi/decls.h>
#include <cosi/cosirand.h>

#ifdef COSI_DEV_COALAPX
#include <cosi/order_statistics.hpp>
#endif


namespace cosi {

namespace coal {


class Coalesce: public HasRandGen {
public:
	 Coalesce( DemographyP demography_ );
	 double coalesce_get_rate (void) const;
	 int coalesce_pick_popindex () const;

	 void setMaxCoalDist( plen_t maxCoalDist_ ) { this->maxCoalDist = maxCoalDist_; }
	 void setMaxCoalDistCvxHull( bool_t maxCoalDistCvxHull_ ) {
		 this->maxCoalDistCvxHull = maxCoalDistCvxHull_;
				}
private:
	 DemographyP demography;
	 plen_t maxCoalDist;
	 bool_t maxCoalDistCvxHull;
	 mutable double lastrate;
	 

};  // class Coalesce


#ifdef COSI_DEV_COALAPX

//
// Namespace: apx
//
// Code related to approximating the coalescent by forbidding some coalescences
// (generally of nodes which share no common genetic material).  We want to directly sample
// from just the intersecting pairs of nodes, rather than using rejection sampling (picking
// an arbitrary node pair and ignoring the coalescence if no intersection).
//
namespace apx {

// Logical type: nlocs_t
// 
typedef int nlocs_t;

struct SkipInfo {
	 // Field: n_begs
	 // Number of begs skipped over by this skip edge
	 nlocs_t n_begs;
	 
	 // Field: n_ends
	 // Number of ends skipped over by this skip edge
	 nlocs_t n_ends;

	 // Field: n_inters
	 // Number of hull intersections 
};  // struct SkipInfo


struct HullLoc {
};

//
// Class: HullMgr
//
// Manages the convex hulls of the active Nodes' Seglists, enabling efficient random sampling of only
// the intersecting hull pairs.  (The convex hull of a seglist is simply the
// segment from its beg to its end, possibly extended at both ends to support detection of near-overlaps ).
// HullMgr supports the following operations:
//
//   Queries:
//
//     - how many pairs of nodes have intersecting convex hulls?
//     - pick a random pair of nodes with intersecting convex hulls, uniformly from all such pairs
//
//   Updates:
//
//     - coalesce two nodes
//     - recombine a node
//     - do a gene conversion
//     - add a node (which migrated from another population)
//     - remove a node (which migrated to another population)
//
// Implementation details:
//
// We keep the following information:
//
//    - for each hull beginning ('beg' for short), the _number_ of hull intersections which start at that
//      point.  Except at 0, this is the number of other hulls which contain this beg, because at each beg
//      except 0 only one hull can start (since hull beginnings are created by randomly choosing a location
//      for recombination).
//
//    - a Fenwick tree of the intersection counts above, to facilitate randomly choosing an intersection
//      by first choosing a hull
//
//    - an interval tree (or other such structure) of the hulls, for quickly counting/enumerating
//      hulls that cover a given point or a given region.
//

} // namespace apx

#endif  // ifdef COSI_DEV_COALAPX

} // namespace coal

}  // namespace cosi

#endif
// #ifndef __COSI_INCLUDE_COALESCE_H
