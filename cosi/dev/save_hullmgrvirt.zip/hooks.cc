
#include <cosi/hooks.h>

namespace cosi {

//
// Class impl: Hook
//

Hook::Hook() { }
Hook::~Hook() { }
void Hook::handle_recomb( Node *, Node *, loc_t ) { }
void Hook::handle_gc( Node *, Node *, loc_t , loc_t ) { }
void Hook::handle_coal( Node * ) {}
void Hook::handle_set_migrate_rate( popid /*from*/, popid /*to*/, prob_per_chrom_per_gen_t /*rate*/ ) { }


// Virtual method: handle_make_leaf
//
// Called whenever a leaf node is created.
void Hook::handle_make_leaf( nodeid /*leafNodeId*/ ) { }


// Virtual method: handle_add_edge
//
// Called after adding an edge to the ARG.  The new edge may be the result of a coalescence,
// a recombination or a gene conversion.
//
// Params:
//
//   nodeId_moreRecent - <nodeid> of the more recent (lower gen) node of the edge
//   nodeId_lessRecent - <nodeid> of the less recent (higher gen) node of the edge.
//   genId_moreRecent - <genid> of the more recent (lower gen) node of the edge
//   genId_lessRecent - <genid> of the less recent (higher gen) node of the edge.
//   seglist - the segments inherited along the edge.  NOTE: this seglist may be destroyed
//       after the call, so make a copy of you need to save it.
//       
void Hook::handle_add_edge( nodeid /*nodeId_moreRecent*/,
														nodeid /*nodeId_lessRecent*/,
														genid /*genId_moreRecent*/,
														genid /*genId_lessRecent*/, const Seglist * /*seglist*/ ) { }

// Virtual method: handle_tree_edge
//
// Called when a tree edge is added.  Only coalescence nodes of the ARG are taken into account; recombination and gc nodes
// are ignored.
//
// Params:
//
//     beg, end - the <Seg> inherited along the edge
//     genMoreRecent, genLessRecent - generations at edge ednpoints
//     leafset - the leafset inherited along the edge
void Hook::handle_tree_edge( loc_t /*beg*/, loc_t /*end*/, genid /*genMoreRecent*/, genid /*genLessRecent*/, leafset_p /*leafset*/ ) { }


// Virtual method: handle_fully_coalesced
//
// Called when, after a coalescence where part of the resulting node's segs has fully coalesced,
// a new node is created to carry the not-yet-coalesced parts of the old node's segs.
void Hook::handle_fully_coalesced( nodeid /*nodeId_old*/, nodeid /*nodeId_new*/, const Seglist * /*seglist_new*/ ) { }

}  // namespace cosi
