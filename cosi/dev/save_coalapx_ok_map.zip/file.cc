/* $Id: file.c,v 1.4 2011/05/06 15:35:43 sfs Exp $ */
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cctype>
#include <sstream>
#include <boost/make_shared.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/filesystem.hpp>
#include <cosi/file.h>
#include <cosi/recomb.h>
#include <cosi/demography.h>
#include <cosi/simulator.h>
#include <cosi/output.h>
#include <cosi/geneconversion.h>
#include <cosi/historical.h>
#include <cosi/sweep.h>

namespace cosi {

static const size_t BUF_MAX = 1024;

ParamFileReader::ParamFileReader( DemographyP demography_ ):
	demography( demography_ ) {
	init();
}

void ParamFileReader::init() {
  seeded = False;
  popsize = 0;
  sampsize = 0;
  length = 0;
  mu = prob_per_bp_per_gen_t( 0.0 );
  recombrate = 0;
	geneConversionRate = 0.0;
	geneConv2RecombRateRatio = factor_t(0.0);
	geneConversionMeanTractLength = 500 /* bp */;
	geneConversionMinTractLength = 4 /* bp */;
	geneConversionModel = GeneConversion::GCM_LEFT_AND_RIGHT_FROM_ORIGIN;
  rseed = 0;

	histEvents = boost::make_shared<HistEvents>( demography );
	infSites = False;
	printSeed = True;
	ignoreRecombsInPop = NULL_POPID;
}


void ParamFileReader::file_read(boost::filesystem::path filename, FILE *segfp) 
{
	init();
	this->paramFileName = filename;
	
	FILE *infileptr = fopen (filename.c_str(), "r");

	if (infileptr == NULL) {
	  printf( "could not open file %s for reading\n", filename.c_str() );
		file_exit("file_read", "cannot open file for reading");
	}

	if (segfp != NULL) {fprintf(segfp, "paramfile: %s\n", filename.c_str());}
	file_get_data (infileptr, segfp);
	fclose(infileptr);
}

/*********************************************************/

int 
ParamFileReader::file_proc_buff(char *var, char* buffer, FILE* segfp) 
{

	popid     popname;
	int  intarg;
	char  err_string[512];
		
	/*	printf("%s\n", var); */
	if (strcmp(var,"length") == 0) {
		length = atoi(buffer);
	}
	else if (strcmp(var,"recomb_file") == 0) {
		if (buffer[strlen(buffer)-1] == '\n')
			 buffer[strlen(buffer)-1] = '\0';
		chkCond( length > 0, "cosi paramfile error: must specify length before recombmap" );

		namespace fs = boost::filesystem;

		fs::path recombFilePath( buffer );
		fs::path paramFileDir( fs::canonical( this->paramFileName ).parent_path() );
		recombFilePath = fs::absolute( recombFilePath /*, paramFileDir */ );
		
		genMap = boost::make_shared<GenMap>( recombFilePath, length );
		assert( genMap.get() );
	}
	else if (strcmp(var, "mutation_rate") == 0) {
		mu = prob_per_bp_per_gen_t( atof(buffer) );
	}
	else if (strcmp(var, "infinite_sites") == 0) {
	  if (buffer[strlen(buffer)-1] == '\n')
			 buffer[strlen(buffer)-1] = '\0';
	  if (strcmp(buffer, "yes") == 0 || strcmp(buffer, "Yes") == 0 || strcmp(buffer, "YES") == 0)
			 infSites = True;
	}
	else if (strcmp(var, "gene_conversion_rate") == 0) {
		geneConversionRate = atof(buffer);
	}
	else if (strcmp(var, "gene_conversion_relative_rate") == 0) {
		geneConv2RecombRateRatio = factor_t( atof(buffer) );
	}
	else if (strcmp(var, "gene_conversion_mean_tract_length") == 0) {
		geneConversionMeanTractLength = atoi(buffer);
	}
	else if (strcmp(var, "gene_conversion_min_tract_length") == 0) {
		geneConversionMinTractLength = atoi(buffer);
	}
	else if (strcmp(var, "gene_conversion_model") == 0) {
		geneConversionModel = GeneConversion::parseGCModel( boost::trim_copy( string( buffer ) ) );
	}
	else if (strcmp(var, "pop_size") == 0) {
		popname = popid( atoi(strtok (buffer, " ")) );
		intarg = atoi(strtok (NULL, " " ));
		if (FILE_DEBUG)
			 printf("popsize: %d\n", intarg);
		/* 
		 * Throw a fatal error if pop [popname] does not exist.
		 */		
		if (! demography->dg_set_pop_size_by_name (ZERO_GEN, popname, intarg))
			 file_exit("file_proc_buff", 
								 "parameter file - pop specified does not exist.");
	}
	else if (strcmp(var, "sample_size") == 0) {		
		popname = popid( atoi(strtok (buffer, " ")) );
		intarg = atoi(strtok (NULL, " " ));
		if (FILE_DEBUG)
			 printf("sampsize: %d\n", intarg);
		demography->dg_populate_by_name (popname, intarg);
		if (segfp != NULL) {fprintf(segfp, "A %d %d\n", ToInt( popname ), intarg);}
	}
	else if ( !strcmp( var, "pop_ignore_recombs" ) ) {
		this->ignoreRecombsInPop = popid( atoi(strtok (buffer, " ")) );
	}
	else if (strcmp(var, "pop_define") == 0) {
		popname = popid( atoi(strtok (buffer, " ")) );
		string pop_label( strtok (NULL, " ") );
		if ( pop_label.empty() ) pop_label = "some_pop";
		if ( pop_label.at( pop_label.size()-1 ) == '\n' )
			 pop_label.resize( pop_label.size()-1 );
		demography->dg_create_pop (popname, pop_label, /* genid=*/ ZERO_GEN);
	}
	else if (strcmp(var, "pop_event") == 0) {
		histEvents->addEvent( histEvents->parseEvent( buffer ) );
	}
	else if (strcmp(var, "random_seed") == 0) {
	  std::istringstream is( buffer );
	  rseed = -1;
	  is >> rseed;
	  if (rseed > 0) {
	    //set_rng_seed(rseed);
//	    if ( printSeed ) std::cerr << "coalescent seed set in param file:" << rseed << "\n";
	    seeded = True;
	  } else
			 cerr << "cosi error -- could not read seed: " << buffer << endl;
	} else if (strcmp(var,"sweep_traj_file") == 0) {
		if (buffer[strlen(buffer)-1] == '\n')
			 buffer[strlen(buffer)-1] = '\0';
		//sweep_set_traj_file(buffer);
	} else {
	  strcpy(err_string, "unknown variable: ");
	  strcat(err_string, var);
	  strcat(err_string, "\n  Arguments for invalid parameter: ");
	  strcat(err_string, buffer);
	  file_exit("file_proc_buffer", 
							err_string);
	  if (FILE_DEBUG)
			 printf("%s is not a valid variable\n", var);
	}

	return 1;
}

int 
ParamFileReader::file_get_data (FILE *fileptr, FILE *segfp) 
{
	char c,
		 buffer[BUF_MAX],
		 var[50];

	c = getc(fileptr);
	while (c != EOF) {
		switch (c) {
		case '#':
			c = getc(fileptr);
			while (c != '\n' && c != EOF)
				 c = getc(fileptr);
			break;
		case '\n':
			c = getc(fileptr);
			break;
		case ' ':
			c = getc(fileptr);
			break;
		default:
			ungetc(c, fileptr);
			fscanf(fileptr, "%s", var);
			file_killwhitespace(fileptr);
			fgets(buffer, BUF_MAX, fileptr);
			file_proc_buff(var, buffer, segfp);
			c = getc(fileptr);
			break;
		}
	}

	// if (!seeded)
	// 	 std::cerr << "coalescent seed: " << ( rseed = seed_rng()) << endl;

	if (segfp != NULL) {fprintf(segfp, "params: length %d mu %.9f\n", length, (double)ToDouble( mu ) );}
	if (segfp != NULL) {fprintf(segfp, "L %d\n", length);}

	return 1;
}

int 
ParamFileReader::file_killwhitespace(FILE * fileptr) 
{
	char c;
	int i = 0;
	c = getc(fileptr);
	while (isspace((int) c)) {
		c = getc(fileptr);
		i++;
	}
	ungetc(c, fileptr);
	return i;
}

/*
 * FILE_EXIT
 */
void 
ParamFileReader::file_exit(const char* funct_name, const char* error_string) 
{
	fprintf(stderr, "file.c | %s: %s\n",
					funct_name, error_string);
	exit(EXIT_FAILURE);
}

void 
ParamFileReader::file_error_nonfatal(const char* funct_name, const char* error_string) 
{
	fprintf(stderr, "file.c | %s: %s\n",
					funct_name, error_string);
}

}  // namespace cosi
