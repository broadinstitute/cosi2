#ifndef __COSI_INCLUDE_POPFWD_H
#define __COSI_INCLUDE_POPFWD_H

#include <boost/shared_ptr.hpp>

namespace cosi {
class Pop;
typedef boost::shared_ptr<Pop> PopP;
}

#endif // #ifndef __COSI_INCLUDE_POPFWD_H
