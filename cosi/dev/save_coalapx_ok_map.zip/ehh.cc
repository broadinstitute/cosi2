#include <iostream>
#include <fstream>
#include <algorithm>
#include <boost/foreach.hpp>
#include <boost/lambda/lambda.hpp>
#include <boost/lambda/casts.hpp>
#include <boost/lambda/bind.hpp>
#include <boost/range/numeric.hpp>
#include <boost/range/irange.hpp>
#include <boost/range/adaptors.hpp>
#include <boost/range/algorithm/copy.hpp>
#include <boost/range/algorithm_ext/erase.hpp>
#include <boost/range/algorithm/for_each.hpp>
#include <boost/range/algorithm_ext/push_back.hpp>
#include <boost/math/special_functions/fpclassify.hpp>
#include <cosi/demography.h>
#include <cosi/ehh.h>

namespace cosi {

namespace ehh {
  
namespace lam = ::boost::lambda;
namespace ad = ::boost::adaptors;
namespace ran = ::boost::range;
using std::cout;
using std::endl;
using std::ios;
using std::ofstream;
using ad::transformed;
using ad::sliced;
using std::make_pair;
using ran::push_back;
  
// Func: computeEHH
// Compute EHH for the given set of leaves, starting from the given core and going
// in a given direction.
vector<ehh_t> computeEHH( const vector<Mut>& mutlist,
													leafset_p coreLeafset,
													ehh_t ehhCutoff ) {

	vector<ehh_t> result;
	result.reserve( mutlist.size() );
	result.push_back( 1.0 );
	vector< leafset_p  > classes;
	classes.push_back( coreLeafset );
	nchroms_t coreLeafsetCardinality = leafset_cardinality( coreLeafset );
	if ( coreLeafsetCardinality >= 2 ) {

		size_t mutNum = 0;
		for ( auto mi = mutlist.begin(); mi != mutlist.end(); mi++ ) {
			const Mut& m = *mi;
			vector< leafset_p  > newClasses;
			assert( m.leaves );
			
			ForEach( leafset_p  cls, classes ) {
				leafset_p inters[2] = { leafset_intersection( cls, m.leaves.get() ),
																leafset_difference( cls, m.leaves.get() ) };
				if ( leafset_is_empty( inters[0] ) || leafset_is_empty( inters[1] ) ) {
					newClasses.push_back( cls );
				} else {
					for ( int i = 0; i < 2; i++ )
						 if ( leafset_cardinality( inters[i] ) > 1 ) newClasses.push_back( inters[i] );
				}
			}
			if ( newClasses.empty() ) break;
			classes = newClasses;
			
			unsigned ehhSum = boost::accumulate( classes | transformed( leafset_cardinality ) | transformed( lam::_1 * ( lam::_1 - 1 ) ),
																					 0 );
			
			ehh_t ehhHere = ((ehh_t)ehhSum) / ((ehh_t)coreLeafsetCardinality * ( coreLeafsetCardinality-1 ) );
			if ( ehhHere < ehhCutoff ) break;
			result.push_back( ehhHere );
		}
		
		if ( result.size() > 1 ) result.pop_back();
	}
	PRINT( result.size() );
	return result;
}  // computeEHH

// Func: computeIHH
// Compute IHH for the given set of leaves, starting from the given core and going
// in a given direction.
ihh_t computeIHH( MutlistP mutlist,
									loc_t coreSNP, dir_t dir,
									leafset_p coreLeafset,
									leafset_p popLeafset,
									ehh_t ehhCutoff ) {
	return 0.0;
	
#if 0	
	vector<Mut> muts = mutlist->getMutsInDir( coreSNP, dir );
	ran::remove_erase_if( muts, lam::bind( &Mut::isMonomorphicIn, lam::_1, popLeafset ) );
	vector<Mut> sideMuts( muts.begin()+1, muts.end() );
	
	vector<ehh_t> ehh = computeEHH( sideMuts, coreLeafset, /*ehhCutoff=*/0.0 );

	vector<glen_t> gdists;
	push_back( gdists, muts | sliced( 0, ehh.size() ) | transformed( lam::bind( &Mut::locGdAdj, lam::_1 ) ) );

	double oneOverN = 1.0 / ((double)leafset_cardinality( popLeafset ) ) ;

	PRINT( ehh.size() );

	std::for_each( ehh.begin()+1, ehh.end(), lam::_1 += oneOverN );

	double cutoffPt = findWhere( ehh, ehhCutoff );

	if ( cutoffPt < 0 ) cutoffPt = ehh.size()-1;

	ran::for_each( ehh, lam::_1 -= ehhCutoff );
	return fabs( integrate( ehh, gdists, 0.0, cutoffPt ) );
#endif	
}  // computeIHH()

}  // namespace ehh

}  // namespace cosi
