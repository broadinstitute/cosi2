/* $Id: pop.c,v 1.3 2011/05/04 15:46:19 sfs Exp $ */
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cosi/pop.h>
#include <cosi/node.h>
#include <cosi/hullmgr.h>
#include <cosi/seglist.h>
#include <cosi/utils.h>

namespace cosi {

using std::string;
using util::chkCond;

Pop::Pop(popid name_, int popsize_, const string& label_) :
	name( name_ ), popsize( popsize_ ), label( label_ )
#ifdef COSI_DEV_COALAPX
	, hullMgr( boost::make_shared<HullMgr>() )
#endif	
#ifdef COSI_DEV	
	, coalRate( 0.0 )
#endif
{
	chkCond( popsize >= 0, "creating pop with negative size" );
}

Pop::~Pop() { }

void Pop::pop_remove_node_by_idx ( int idx_in_pop) {
	Node *n = members[ idx_in_pop ];
  nodelist_remove_idx( &(members), idx_in_pop );
	Node::PopAccess::SetNodePop( n, NULL );
#ifdef COSI_DEV_COALAPX
	hullMgr->removeHull( n->getHull() );
	chkHullMgr();
#endif	
}

void 
Pop::pop_remove_node ( Node *nodeptr) 
{
  assert( nodeptr );
	assert( nodeptr->getPop() == this );
	assert( members[ nodeptr->get_idx_in_pop() ] == nodeptr );
  pop_remove_node_by_idx( nodeptr->get_idx_in_pop() );
}

void 
Pop::pop_add_node ( Node *nodeptr) 
{
	Node::PopAccess::SetNodePop( nodeptr, this );
  nodeptr->set_idx_in_pop( nodelist_add(&(members), nodeptr) );
#ifdef COSI_DEV_COALAPX	
	Node::PopAccess::SetNodeHull( nodeptr, hullMgr->addHull( nodeptr, seglist_beg( nodeptr->getSegs() ), seglist_end( nodeptr->getSegs() ) ) );
	chkHullMgr();
#endif		 
}

#ifdef COSI_DEV_COALAPX
void Pop::setCoalMargin( len_t margin_ ) { hullMgr->setMargin( margin_ ); }

bool Pop::restrictingCoalescence() const { return hullMgr->getMargin() < ( MAX_LOC - MIN_LOC ); }

nchromPairs_t Pop::getNumCoalesceableChromPairs() const {
	return hullMgr->getNumIntersections();
}


void Pop::chkHullMgr() const {

#if !defined(NDEBUG) && defined(COSI_DEV_COALAPX)
	typedef HullMgr::ninters_t ninters_t;

	nchromPairs_t npairs = 0;
	nchromPairs_t npairs_tot = 0;
	len_t maxCoalDist = hullMgr->getMargin();

	//PRINT2( maxCoalDist, members.size() );
	for ( size_t ii = 0; ii < members.size(); ii++ ) {
		const Node *node1 = members[ ii ];
		for ( size_t jj = ii+1; jj < members.size(); jj++ ) {
			const Node *node2 = members[ jj ];
			npairs_tot++;
			if (	!( seglist_beg( node1->getSegs() ) - seglist_end( node2->getSegs() ) > maxCoalDist ||
							 seglist_beg( node2->getSegs() ) - seglist_end( node1->getSegs() ) > maxCoalDist ) ) {
				npairs++;
			}
		}
	}
			
	//hullMgr.chkMap( loc2count );

	typedef util::order_statistics_tree<ploc_t> ost_t;
	typedef ost_t::iterator ost_iter_t;
	ost_t begs, ends;
			
	nchroms_t n_beg0 = 0;
	for ( size_t ii = 0; ii < members.size(); ii++ ) {
		const Node *n = members[ ii ];
		ploc_t beg( get_ploc( seglist_beg( n->getSegs() ) ) );
		if ( beg == ploc_t(0.0) )
			 n_beg0++;
		else
			 begs.insert( beg );

		ploc_t end_ext = get_ploc( seglist_end( n->getSegs() ) ) + maxCoalDist;
		if (  end_ext < ploc_t(1.0) )
			 ends.insert( end_ext );
	}
	nchromPairs_t n_pairs2 = n_beg0 * (n_beg0-1) / 2;
	for ( ost_iter_t bi = begs.begin(); bi != begs.end(); bi++ ) {
		ost_iter_t closestEnd = ends.lower_bound( *bi );
		nchroms_t n_end_before = closestEnd == ends.end() ? ends.size() : closestEnd.position();
		nchroms_t n_beg_after = begs.size() - bi.position();

		n_pairs2 += ( members.size() - n_end_before - n_beg_after );
	}

//	PRINT4( npairs_tot, npairs, n_pairs2, hullMgr->getNumIntersections() );
	static size_t nchecked = 0;

	nchecked++;
	if (  n_pairs2 != npairs  || hullMgr->getNumIntersections() != n_pairs2 ) {
		PRINT4( npairs_tot, npairs, n_pairs2, hullMgr->getNumIntersections() ); 
//				PRINT2( n_pairs2, lastIntersCount );
		throw std::runtime_error( "inters count mismatch" );
	} else {
		if ( !( nchecked % 10000 ) ) {
			PRINT6( nchecked, npairs_tot, npairs, n_pairs2, hullMgr->getNumIntersections(), hullMgr->getMargin() );
		}
	}

			
	//coalRate = ((double)n_pairs2) / ( 2 * std::max(popsize,1) );
	//PRINT3( npairs, npairs_tot, coalRate );

#endif  // #ifndef NDEBUG
	
}  // Pop::chkHullMgr()

#endif // #ifdef COSI_DEV_COALAPX


}
