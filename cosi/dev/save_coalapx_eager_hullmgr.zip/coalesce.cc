/* $Id: coalesce.c,v 1.3 2011/05/04 15:46:19 sfs Exp $ */

#include <algorithm>
#include <map>
#include <stdexcept>
#include <boost/foreach.hpp>
#include <cosi/coalesce.h>
#include <cosi/demography.h>
#include <cosi/node.h>
#include <cosi/seglist.h>

#ifdef COSI_DEV_COALAPX
#include <cosi/order_statistics.hpp>
#endif

namespace cosi {

namespace coal {

extern size_t lastIntersCount;

Coalesce::Coalesce( DemographyP demography_ ):
	demography( demography_ ), lastrate(0.0), maxCoalDist( plen_t( 1.0 ) ), maxCoalDistCvxHull( False ) { }


	
/* 
 * Calculates the coalesce rate according to the number of
 * nodes in each population. 
 */
double 
Coalesce::coalesce_get_rate (void) const
{
	int numpops = demography->dg_get_num_pops();
	int i;
	double rate = 0;
	nchroms_t numnodes;
	nchroms_t popsize;

	
	for (i = 0; i < numpops; i++) {
		numnodes = demography->dg_get_num_nodes_in_pop_by_index (i);
		popsize = demography->dg_get_pop_size_by_index (i);
		if (numnodes > 1  /*&& popsize > 0*/ ) {
			prob_t coalRate = (double) (numnodes * (numnodes - 1)) 
				/ (4 * std::max( popsize, 1 ) );
#ifdef COSI_DEV_COALAPX
//			Pop *popptr = demography->dg_get_pop_by_index (i);

			coalRate = demography->dg_getNodePool()->getNumCoalesceableChromPairs() / ( 2.0 * std::max( popsize, 1 ) );
			
#endif  // #ifdef COSI_DEV_COALAPX			
			
#ifdef COSI_DEV			
			demography->dg_get_pop_by_index( i )->setCoalRate( coalRate );
#endif			
			rate += coalRate;
		}
	}
	
	lastrate = rate;
	return rate;
}

int
Coalesce::coalesce_pick_popindex () const
{
	double  rate = 0,
		 randcounter = random_double() * lastrate;
	int     popindex = 0,
		 numpops = demography->dg_get_num_pops(),
		 numnodes,
		 popsize,
		 i;

	if (numpops > 1) {
		for (i = 0; i < numpops && randcounter > rate; i++) {
			numnodes = demography->dg_get_num_nodes_in_pop_by_index (i);
			popsize = demography->dg_get_pop_size_by_index (i);
			if (numnodes > 1 /*&& popsize > 0*/ )
				 rate += (double) (numnodes * (numnodes - 1)) 
					 / (4 * std::max( popsize, 1 ) );
		}		
		popindex = i - 1;
	}

	return popindex;
}  // Coalesce::coalesce_pick_popindex()

#ifdef COSI_DEV_APX
#endif  // #ifdef COSI_DEV_APX

}  // namespace coal

}  // namespace cosi
