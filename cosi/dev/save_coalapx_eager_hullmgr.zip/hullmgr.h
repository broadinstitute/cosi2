#ifndef __COSI_INCLUDE_HULLMGR_H
#define __COSI_INCLUDE_HULLMGR_H

#include <cstdlib>
#include <utility>
#include <cosi/defs.h>
#include <cosi/order_statistics.hpp>
#include <cosi/utils.h>
#include <cosi/decls.h>

namespace cosi {

namespace node { class Node; }

#ifdef COSI_DEV_COALAPX

//
// Class: HullMgr
//
// Keeps track of the convex hulls of the seglists of all <Nodes>, and of the pairs of intersecting hulls.
// Supports choosing a pair of intersecting hulls uniformly at random from all such intersecting pairs, and
// updating the hull information through all standard operations (recombinations, coalescences,
// gene conversions, migrations).
//
// Complexity:
//
//    space complexity - for n hulls, O(n) storage.
//    time complexity - O(lg n) for update operations.
//
// Implementation notes:
//
// Because recombination points are chosen randomly on a uniform line, we assume that no two such points
// fall into exactly the same place.  So, at each loc except <MIN_LOC>, nbegs+nends <= 2 where nbegs is
// the number of hulls starting at that loc and nends is the number of hulls ending at that loc.
//
// Design rationale:
//
//    - why a simple weighted interval map is not enough?  we need to keep partial sums.  but, presumably
//      a map does that?   
//
// Implementation todo:
//
//   - handle additional cases
//
//       - when something fully coalesces
//       - migration in and out
//       - gene conversion (can/should we re-implement it as a pair of recombs?)
//
//   - keep track of node ids
//
//   - consider using knowledge of the genetic map to optimize access times to elements in hotspots.
//     note though, that for coalescence operations we might need different access probabilities.
//     but, we have some info on them if we keep the intersection counts.
//
//   - zero things out instead of deleting?
//
//   - remove seglist_summaries if no longer helpful
//
//   - avoid multiple tree traversals
//     - support finding several cose-by things at once
//
class HullMgr {
public:

	 typedef node::Node Node;

	 // Logical type: ninters_t
	 // A count of hull intersections; has units of nchroms * nchroms.
	 typedef int ninters_t;  // signed, for now, to allow negative deltas.

	 // Constructor: HullMgr
	 // Construct a HullMgr.  It is not yet initialized (see <addLeaves()> for that).
	 // Params:
	 //    margin_ - specifies what near-intersections are considered to be intersections;
	 //      specifically, for a seglist [beg,end] the corresponding hull is [beg, end+margin].
	 HullMgr();
	 virtual ~HullMgr();

	 void setMargin( len_t margin_ ) { this->margin = margin_; }
	 void setMargin( plen_t margin_ ) { this->setMargin( len_t( margin_ ) ); }

	 len_t getMargin() const { return this->margin; }

	 // Method group: ARG operations

	 void addHull( Node *node, loc_t beg, loc_t end ); 
	 void removeHull( Node *node, loc_t beg, loc_t end ); 

	 // Method: recomb
	 //
	 // Called after each recombination to update the hull information.
	 //
	 // Params:
	 //
	 //    beg1,end1 and beg2,end2 - the two hulls resulting from the recombination.
	 //      The original hull was [beg1,end2].  If the recomb point fell in the middle of a seg,
	 //      then end1 == beg2.  If the recomb point fell in a gap, then end1 < beg2.
	 //
	 //    loc - the location of recombination
	 //
	 // Complexity: lg n, where n is the current number of hulls.
	 //
	 void recomb( Node *oldNode, Node *newNode1, Node *newNode2, loc_t beg1, loc_t end1, loc_t beg2, loc_t end2, loc_t loc );
	 
	 void coalesce( Node *node1, Node *node2, loc_t beg1, loc_t end1, loc_t beg2, loc_t end2 );
	 void coalesce( Node *node1, Node *node2, Node *newNode, loc_t beg1, loc_t end1, loc_t beg2, loc_t end2, loc_t newbeg, loc_t newend );

	 // End method group: ARG operations


	 // Method group: Debugging / testing
	 
	 // Method: chkMap
	 // Check that the inters counts represented by this HullMgr match the counts in the passed map.
	 void chkMap( const map< loc_t, ninters_t >& ) const;

private:
	 // Field: margin
	 //
	 // Specifies what near-intersections are considered to be intersections;
	 // specifically, for a seglist [beg,end] the corresponding hull is [beg, end+margin].
	 // So, two seglists [beg1,end1] and [beg2,end2] where end1 < beg2 have intersecting hulls
	 // if end1 is within 'margin' of beg2.
	 len_t margin;

	 // Struct: HullBeg
	 // A loc at which a hull begins.
	 struct HullBeg {
			// Field: loc
			// The loc.
			loc_t loc;

			// Field: ninters
			// The number of intersections which start at <loc>.
			ninters_t ninters;

			// Field: node
			// The Node whose hull's beginning we represent.
			Node *node;

			HullBeg(): loc( NULL_LOC ), ninters( 0 ), node( NULL ) { }
			HullBeg( loc_t loc_, ninters_t ninters_, Node * node_ ):
				loc( loc_ ), ninters( ninters_ ), node( node_ ) { }
	 };  // struct HullBeg
	 
	 // Type: ost_t
	 // An Order Statistics Tree which lets us efficiently query, for each element, the number
	 // of elements less than it.
	 typedef util::order_statistics_tree< /* ValueType= */ HullBeg,
																				/* Comparator= */ std::less<loc_t>,
																												 /* KeyExtractor= */ util::FieldRef< HullBeg, loc_t, &HullBeg::loc > ,
																												 /* WeightExtractor= */ util::FieldRef< HullBeg, ninters_t, &HullBeg::ninters > > ost_begs_t;
	 
	 typedef ost_begs_t::iterator ost_begs_iter_t;

	 // Field: begs
	 // For each beg >0 , the number of intersections starting there.
	 ost_begs_t begs;

	 // Struct: HullEnd
	 // A loc at which a hull begins.
	 struct HullEnd {
			// Field: loc
			// The loc.
			loc_t loc;

			// Field: node
			// The Node whose hull's end we represent.
			Node *node;

			struct LocRange {
				 loc_t locMin;
				 loc_t locMax;

				 LocRange(): locMin( MAX_LOC ), locMax( MIN_LOC ) { }
				 LocRange( loc_t oneLoc ): locMin( oneLoc ), locMax( oneLoc ) { }
				 LocRange( loc_t locMin_, loc_t locMax_ ): locMin( locMin_ ), locMax( locMax_ ) { }

				 LocRange& operator+=( const LocRange& other ) {
					 locMin = std::min( locMin, other.locMin );
					 locMax = std::max( locMax, other.locMax );
					 return *this;
				 }

				 friend LocRange operator+( const LocRange& r1, const LocRange& r2 ) {
					 return LocRange( std::min( r1.locMin, r2.locMin ), std::max( r1.locMax, r2.locMax ) );
				 }
			};

			// Field: beg
			// The beg of the corresponding hull
			loc_t beg;

			HullEnd(): loc( NULL_LOC ), node( NULL ), beg( NULL_LOC ) { }
			HullEnd( loc_t loc_, Node * node_, loc_t beg_ ):
				loc( loc_ ), node( node_ ), beg( beg_ ) { }
	 };  // struct HullEnd

	 struct LocRangeExtractor {
			typedef HullEnd argument_type;
			typedef HullEnd::LocRange result_type;
			typedef HullEnd::LocRange value_type;

			HullEnd::LocRange operator()( const HullEnd& h ) const { return HullEnd::LocRange( h.beg ); }
	 };
	 
	 typedef util::order_statistics_tree< /* ValueType= */ HullEnd,
																												 /* Comparator= */ std::less<loc_t>,
																												 /* KeyExtractor= */ util::FieldRef< HullEnd, loc_t, &HullEnd::loc >,
																												 /* WeightExtractor= */ LocRangeExtractor > ost_ends_t;
	 typedef ost_ends_t::iterator ost_ends_iter_t;

	 // Field: ends
	 // The locations of hull ends.
	 ost_ends_t ends;

	 // Field: nbegs0
	 // Number of hulls beginning at MIN_LOC
	 nchroms_t nbegs0;

	 // Field: nodes0
	 // Nodes starting at 0
	 util::order_statistics_tree< Node * > nodes0;

public:

	 // Method: getNumIntersections
	 // Returns the current number of intersecting hull pairs.
	 ninters_t getNumIntersections() const { return nbegs0 * (nbegs0 - 1) / 2  +  begs.totalWeight(); }

	 // Method: chooseRandomIntersection
	 // Pick and return a pair of intersecting hulls, uniformly at random from all such pairs.
	 std::pair< Node *, Node * > chooseRandomIntersection( RandGenP randGen ) const;
	 

};  // class HullMgr

#endif  // #ifdef COSI_DEV_COALAPX

}  // namespace cosi

#endif  // #ifndef __COSI_INCLUDE_HULLMGR_H
